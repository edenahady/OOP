// ID: 318948106
import biuoop.DrawSurface;
import biuoop.GUI;
import java.awt.Color;
import java.awt.Point;


/**
 * creating the GameBoard class.
 */
public class GameBoard implements Sprite {
    private GUI gui;
    private int height;
    private int width;
    private int margin;
    private Block top;
    private Block right;
    private Block left;
    private Block bottom;
    private Rectangle recInfo;
    private Color bordersColor;
    //private Color infoRecColor;
    private String levelName;


    /**
     * constructor.
     * @param gui    the gui of the screen's game
     * @param height the height of the screen of the game
     * @param width  the width of the screen of the game
     * @param margin the margin of the screen of the game
     * @param levelName the name of the level to be presented
     */
    public GameBoard(GUI gui, int height, int width, int margin, String levelName) {
        this.gui = gui;
        this.height = height;
        this.width = width;
        this.margin = margin;
        this.recInfo = new Rectangle(new Point(0 , 0) , this.width() , this.getMargin() + 15);
        this.bordersColor = new Color(113, 89, 128);
        //this.infoRecColor = new Color(143, 73, 133);
        this.createBorderBlocks();
        this.levelName = levelName;
    }

    /**
     * This mathod creates the top bottom left and right blocks.
     */
    public void createBorderBlocks() {
        // buliding the borders of the screen
        this.left = new Block(new Rectangle(new Point(0, 20), this.margin, this.height()));

        this.top = new Block(new Rectangle(new Point(0, 20)
                , this.width, this.margin));

        this.bottom = new Block(new Rectangle(new Point(0, 580
        ), this.width(), this.margin));
        this.right = new Block(new Rectangle(new Point(780
                , 20), this.margin, this.height()));
    }

    /**
     * This mathod setes the borderblocks color.
     * @param c the new color
     */
    public void setBorderColor(Color c) {
        this.bordersColor = c;
    }

    /**
     * This mathod setes the infoRec color.
     * @param c the new color
//     */
//    public void setInfoRecColor(Color c) {
//        this.infoRecColor = c;
//    }

    /**
     * this mathod returns the bottom block.
     * @return the bottom block
     */
    public Block getBottom() {
        return this.bottom;
    }

    /**
     * this mathod returns the inforec block.
     * @return the info rec- the rec on which the level name, score ant lives are presented
     */
    public Rectangle getInfoRec() {
        return this.recInfo;
    }

    /**
     * adds the borders to the coliidables list of the game.
     * @param g the game to which the coliidable are added
     */
    public void addBordersToCollidable(GameLevel g) {
        g.addCollidable(this.bottom);
        g.addCollidable(this.left);
        g.addCollidable(this.right);
        g.addCollidable(this.top);

    }

    /**
     * returns the gui of the game.
     *
     * @return the gui of the game
     */
    public GUI getGui() {
        return this.gui;

    }

    /**
     * returns the height of the game.
     *
     * @return the height of the game
     */
    public int height() {
        return this.height;

    }

    /**
     * returns the width of the game.
     *
     * @return the width of the game
     */
    public int width() {
        return this.width;

    }

    /**
     * returns the Margin of the game.
     *
     * @return the Margin of the game
     */
    public int getMargin() {
        return this.margin;
    }
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.bordersColor);
//        d.setColor(Color.black);
        this.left.drawOn(d);
        this.bottom.drawOn(d);
        this.right.drawOn(d);
        this.top.drawOn(d);

//        d.setColor(this.infoRecColor);
//        d.fillRectangle((int) Math.round(this.recInfo.getUpperLeft().getX())
//                , (int) Math.round(this.recInfo.getUpperLeft().getY())
//                , (int) Math.round(this.recInfo.getWidth()), (int) Math.round(this.recInfo.getHeight()));

//        d.setColor(new Color(20, 177, 217));
//        d.drawText((int) Math.round(this.recInfo.getUpperLeft().getX())
//                        + (int) Math.round(this.recInfo.getWidth()) * 3 / 4
//                , ((int) Math.round(this.recInfo.getUpperLeft().getY()
//                        + (int) Math.round(this.recInfo.getHeight()) / 2 + 5)),
//                "Level: " + this.levelName, 17);
    }

    @Override
    public void timePassed() {

    }
}
