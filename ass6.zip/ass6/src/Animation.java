//ID: 318948106
import biuoop.DrawSurface;

/**
 * creating the Animation interface.
 */
public interface Animation {
    /**
     * this method creating one frame of the surface.
     * @param d is our surface
     */
    void doOneFrame(DrawSurface d);

    /**
     * this method is asking if the game needs to stop.
     * @return yes if the game should stop, else false
     */
    boolean shouldStop();

}
