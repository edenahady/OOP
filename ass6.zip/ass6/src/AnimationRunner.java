//ID: 318948106
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * creating the AnimationRunner class.
 */
public class AnimationRunner {
        private final GUI gui;
        private final int framesPerSecond;
        private final Sleeper sleeper;
        /**
         * constructor to AnimationRunner.
         * @param gui is the gui
         * @param framesPerSecond the frames per second
         * @param sleeper is the sleeper
         */
        public AnimationRunner(GUI gui, int framesPerSecond, Sleeper sleeper) {
            this.gui = gui;
            this.framesPerSecond = framesPerSecond;
            this.sleeper = sleeper;
        }

        /**
         * this method is runing the game.
         * @param animation the animation
         */
        public void run(Animation animation) {
            int millisecondsPerFrame = 1000 / this.framesPerSecond;
            while (!animation.shouldStop()) {
                long startTime = System.currentTimeMillis(); // timing
                DrawSurface d = this.gui.getDrawSurface();
                animation.doOneFrame(d);
                this.gui.show(d);
                long usedTime = System.currentTimeMillis() - startTime;
                long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
                if (milliSecondLeftToSleep > 0) {
                    this.sleeper.sleepFor(milliSecondLeftToSleep);
                }
            }
        }

    /**
     *
     * @return the gui.
     */
    public GUI getGui() {
            return this.gui;
        }

        /**
         * Close gui.
         */
        public void closeGui() {
            this.gui.close();
        }
    }

