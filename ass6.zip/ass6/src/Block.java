//ID 318948106

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import biuoop.DrawSurface;

/**
 * creating the block class.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle r;
    private Color color;
    private int health;
    private List<HitListener> hitListeners;

    /**
     * Constructor of Block by a single Rectangle.
     *
     * @param r is a rectangle
     */
    public Block(Rectangle r) {

        this.r = r;
        this.hitListeners = new ArrayList<HitListener>();
        this.color = new Color(10 , 10 , 10);
    }

    /**
     * Constructor of Block by an upper left point, width and a height
     * (just like a rectangle).
     *
     * @param upperLeft is the upper left point of the block
     * @param width     is the width of the block
     * @param height    is the height of the block
     */
    public Block(Point upperLeft, double width, double height) {

        this.r = new Rectangle(upperLeft, width, height);
        this.hitListeners = new ArrayList<HitListener>();
        this.color = new Color(10 , 10 , 10);
    }

    /**
     * Constructor of Block by a single Rectangle and a color.
     *
     * @param r is a rectangle
     * @param c is the block color
     */
    public Block(Rectangle r, Color c) {
        this.r = r;
        this.color = c;
        this.hitListeners = new ArrayList<HitListener>();
    }

    /**
     * This method returns the collision rectangle.
     *
     * @return collision rectangle
     */
    public Rectangle getCollisionRectangle() {
        return this.r;
    }

    /**
     *
     * @return the left hits of the ball
     */
    public int getHealth() {
        return this.health;
    }

    /**
     * This method sets the block health.
     *
     * @param h is the hit points to set it to
     */
    public void setHealth(int h) {

        this.health = h;
    }

    /**
     * This method returns the color of a Block.
     *
     * @return color of a Block.
     */
    public Color getColor() {
        return this.color;
    }

    /**
     * This method sets the color of a Block.
     *
     * @param c is the color
     */
    public void setColor(Color c) {
        this.color = c;
    }


    /**
     * @param collisionPoint  is the collision point.
     * @param currentVelocity is the current velocity
     * @param hitter is our ball
     * @return the new velocity
     */
    public Velocity hit(Ball hitter , Point collisionPoint, Velocity currentVelocity) {
        if (this.health > 0) {
            this.health = this.health - 1;
        }
        List<Line> rectDune = this.r.getDune();
        Velocity newVelocity = new Velocity(currentVelocity.getDx(), currentVelocity.getDy());

        // check which rib of the block the ball has hit and create a new velocity by that.
        if (rectDune.get(0).isPointInLine(collisionPoint) || rectDune.get(2).isPointInLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getDx(), currentVelocity.getDy() * -1);
        } else if (rectDune.get(1).isPointInLine(collisionPoint) || rectDune.get(3).isPointInLine(collisionPoint)) {
            newVelocity = new Velocity(currentVelocity.getDx() * -1, currentVelocity.getDy());
        }
        this.notifyHit(hitter);
        return newVelocity;
    }

    /**
     * @param surface is our surface we draw on.
     */
    public void drawOn(DrawSurface surface) {
        int xUppLeft = (int) r.getUpperLeft().getX();
        int yUpperLeft = (int) r.getUpperLeft().getY();
        int width = (int) r.getWidth();
        int height = (int) r.getHeight();
        surface.setColor(this.color);
        surface.fillRectangle(xUppLeft, yUpperLeft, width, height);
        surface.setColor(Color.black);
        surface.drawRectangle(xUppLeft, yUpperLeft, width, height);
    }

    @Override
    /**
     * notice the ball that time has passed.
     */
    public void timePassed() {

    }

    /**
     * this method adding the collidable and sprite to game.
     *
     * @param game is our game.
     */
    public void addToGame(GameLevel game) {
        game.addCollidable(this);
        game.addSprite(this);
    }

    @Override
    /**
     * this method adds hl to the HitListener list.
     */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    @Override
    /**
     * this method removes hl from the HitListener list.
     */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * this method notify that hit happened.
     * @param hitter is our ball
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }

    /**
     * this method removes the block from the game.
     * @param game is our game
     */
    public void removeFromGame(GameLevel game) {
        game.removeSprite(this);
        game.removeCollidable(this);
    }
}
