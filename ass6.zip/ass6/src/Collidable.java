//ID 318948106

/**
 * creating the collidable interface.
 */
public interface Collidable {

    /**
     *
     * @return the collision shape of the object.
     */
    Rectangle getCollisionRectangle();

    // Notify the object that we collided with it at collisionPoint with
    // a given velocity.
    // The return is the new velocity expected after the hit (based on
    // the force the object inflicted on us).

    /**
     *
     * @param collisionPoint is the collision point.
     * @param currentVelocity is the current velocity.
     * @param hitter is the ball.
     * @return the hit point.
     */
    Velocity hit(Ball hitter, java.awt.Point collisionPoint, Velocity currentVelocity);
}

