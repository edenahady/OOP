// ID: 318948106
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * creating the AllPink class.
 */
public class AllPink implements LevelInformation {
    private int numberOfBalls;
    private List<Velocity> ballsVelocities;
    private int paddleSpeed;
    private int paddleWidth;
    private String levelName;
    private Sprite background;
    private List<Block> blocks;
    private int numberOfBlocksToRemove;
    private List<Ball> balls;
    /**
     * Constructor of Pink View level.
     */
    public AllPink() {
        this.numberOfBalls = 2;
        this.ballsVelocities = new ArrayList<Velocity>();
        this.ballsVelocities.add(Velocity.fromAngleAndSpeed(300, 5));
        this.ballsVelocities.add(Velocity.fromAngleAndSpeed(60, 5));
        this.paddleSpeed = 8;
        this.paddleWidth = 100;
        this.levelName = "All Pink";
        this.background = new AllPinkBackground();
        this.blocks = new ArrayList<Block>();

        // Create the blocks
        int x = 800 - 70;
        int y = 100;
        Random rand = new Random();

        for (int i = 0; i < 5; i++) {

            // Create random color of each row
            int colorR = rand.nextInt(255) + 1;
            int colorG = rand.nextInt(255) + 1;
            int colorB = rand.nextInt(255) + 1;
            Color randomColor = new Color(colorR, colorG, colorB);

            // Create one block's row
            for (int j = 0; j < 10 - i; j++) {
                Rectangle rect = new Rectangle(new Point(x, y), 50, 30);
                Block block = new Block(rect, randomColor);
                this.blocks.add(block);
                x -= 50;
            }
            y += 30;
            x = 800 - 70;
        }

        this.numberOfBlocksToRemove = 40;

        // Create the balls
        this.balls = new ArrayList<Ball>();
        this.balls.add(new Ball(300, 400, 5, java.awt.Color.WHITE));
        this.balls.add(new Ball(500, 400, 5, java.awt.Color.WHITE));
    }

    @Override
    /**
     *@return the number of balls.
     */
    public int numberOfBalls() {
        return this.numberOfBalls;
    }

    @Override
    /**
     * @return the velocities of the balls.
     */
    public List<Velocity> initialBallVelocities() {
        return this.ballsVelocities;
    }

    @Override
    /**
     * @return the paddle speed
     */
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    /**
     * @return the width of the paddle.
     */
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    /**
     * @return the name of the game.
     */
    public String levelName() {
        return this.levelName;
    }

    @Override
    /**
     * @return the background.
     */
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    /**
     * @return the list of blocks.
     */
    public List<Block> blocks() {
        return this.blocks;
    }

    @Override
    /**
     * @return the list of balls.
     */
    public List<Ball> balls() {
        this.balls = new ArrayList<Ball>();
        this.balls.add(new Ball(300, 400, 5, java.awt.Color.WHITE));
        this.balls.add(new Ball(500, 400, 5, java.awt.Color.WHITE));
        return this.balls;
    }

    @Override
    /**
     * @return the number of block we need to remove.
     */
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }
}
