// ID: 318948106
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 * creating the DirectHit class.
 */
public class DirectHit implements LevelInformation {
    private int numberOfBalls;
    private List<Velocity> ballsVelocities;
    private int paddleSpeed;
    private int paddleWidth;
    private String levelName;
    private Sprite background;
    private List<Block> blocks;
    private int numberOfBlocksToRemove;
    private List<Ball> balls;

    /**
     * Constructor of Direct hit level.
     */
    public DirectHit() {
        this.numberOfBalls = 1;
        this.ballsVelocities = new ArrayList<Velocity>();
        this.ballsVelocities.add(Velocity.fromAngleAndSpeed(360, 5));
        this.paddleSpeed = 8;
        this.paddleWidth = 100;
        this.levelName = "Direct Hit";
        this.background = new DirectHitBackground();
        this.blocks = new ArrayList<Block>();
        Rectangle rect = new Rectangle(new Point(381, 146), 40, 40);
        Block block = new Block(rect, new Color(255, 102, 102));
        this.blocks.add(block);
        this.numberOfBlocksToRemove = 1;
        this.balls = new ArrayList<Ball>();
        this.balls.add(new Ball(400, 500, 5, java.awt.Color.WHITE));
    }

    @Override
    public int numberOfBalls() {
        return this.numberOfBalls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        return this.ballsVelocities;
    }

    @Override
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    public String levelName() {
        return this.levelName;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    @Override
    public List<Ball> balls() {
        this.balls = new ArrayList<Ball>();
        this.balls.add(new Ball(400, 500, 5, java.awt.Color.WHITE));
        return this.balls;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }
}
