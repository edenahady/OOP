//ID: 318948106
/**
 * creating the BlockRemover class.
 */
public class BlockRemover implements HitListener {
    private GameLevel game;
    private Counter removedBlock;

    /**
     * constructor to BlockRemover.
     * @param game is our game
     * @param removedBlocks is the current number of blocks
     */
    public BlockRemover(GameLevel game, Counter removedBlocks) {
        this.game = game;
        this.removedBlock = removedBlocks;
    }

    /**
     * this method removes the blocks from the game.
     * @param beingHit is the block being hit
     * @param hitter is the ball that hit the block
     */

    public void hitEvent(Block beingHit, Ball hitter) {
       if (beingHit.getHealth() == 0) {
           this.removedBlock.decrease(1);
           beingHit.removeFromGame(this.game);
           beingHit.removeHitListener(this);
       }
    }

    /**
     * this method is setting the counter.
     * @param blocksLeft is the blocks that left on the game.
     */
    public void setCounter(Counter blocksLeft) {
        this.removedBlock = blocksLeft;
    }
}
