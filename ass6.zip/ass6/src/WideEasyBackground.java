// ID: 318948106
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * creating the WideEasyBackground class.
 */
public class WideEasyBackground implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {
        // background
        d.setColor(Color.WHITE);
        d.fillRectangle(0, 0, d.getWidth(), d.getHeight());

        // sunlights
        int x = 10;
        int y = 300;
        while (x <= 790) {
            d.setColor(new Color(239, 231, 176));
            d.drawLine(150, 150, x, y);
            x += 7;
        }

        // sun
        d.setColor(new Color(239, 231, 176));
        d.fillCircle(150, 150, 60);
        d.setColor(new Color(236, 215, 73));
        d.fillCircle(150, 150, 50);
        d.setColor(new Color(255, 225, 24));
        d.fillCircle(150, 150, 40);

        // sky
        d.setColor(new Color(10, 153, 255));
        for (int i = 0; i < 900; i += 90) {
            d.fillCircle(i, -25, 100);
        }

        d.setColor(new Color(102, 178, 255));
        for (int i = 0; i < 900; i += 90) {
            d.fillCircle(i, -25, 90);
        }

        d.setColor(new Color(153, 204, 255));
        for (int i = 0; i < 900; i += 90) {
            d.fillCircle(i, -25, 80);
        }

    }

    @Override
    public void timePassed() {

    }
}
