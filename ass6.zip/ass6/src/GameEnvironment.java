//ID 318948106

import java.util.ArrayList;
import java.util.List;
import java.awt.Point;

/**
 * creating the game environment class.
 */
public class GameEnvironment {
    private List<Collidable> colList;

    /**
     * constructor to game environment.
     */
    public GameEnvironment() {
        this.colList = new ArrayList<Collidable>();
    }

    /**
     * this method adding the given collidable to the environment.
     *
     * @param c is the collidable we want to add.
     */
    public void addCollidable(Collidable c) {
        colList.add(c);
    }

    /**
     * @return the list of collidables.
     */
    public List<Collidable> getColList() {
        return colList;
    }

    // Assume an object moving from line.start() to line.end().
    // If this object will not collide with any of the collidables
    // in this collection, return null. Else, return the information
    // about the closest collision that is going to occur.

    /**
     * @param trajectory is the line.
     * @return the closest collision point.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        CollisionInfo collisionInfo = null;
        for (Collidable collidable : colList) {
            Rectangle rect = collidable.getCollisionRectangle();
            Point closestPoint = trajectory.closestIntersectionToStartOfLine(rect);
//            System.out.println(closestPoint.toString());
            if (closestPoint != null) {
                collisionInfo = new CollisionInfo(closestPoint, collidable);
                break;
            }
        }
        return collisionInfo;

    }

    /**
     * this method gets a ball and checks if it got stuck in
     * a collidable object. if so, resets it's location
     * to the bottom of the screen.
     * @param ball the given ball.
     */
//    public void stuckProblem(Ball ball) {
//        Random random = new Random();
//        if (this.colList.isEmpty()) {
//            return;
//        }
//        for (Collidable obj : colList) {
//            if (obj.getCollisionRectangle().
//                    isContainPoint(ball.getCenter())) {
//                ball.setCenter(350 + random.nextInt(100), 450);
//
//            }
//        }
//    }
    public void stuckProblem(Ball ball) {
        if (colList.isEmpty()) {
            return;
        }
        for (Collidable collStuck : colList) {
            Rectangle colRect = collStuck.getCollisionRectangle();
            // get the collidable the ball is stuck in
            if (colRect.isContainPoint(ball.getCenter())) {
                if (collStuck.getClass().getName() == "Paddle") {
                    ball.setCenter(ball.getX(), 600 - 20
                            - 20 - ball.getSize());
                    return;
                }
                if ((ball.getY() >= 0) || (ball.getY() <= 20)) {
                    ball.setCenter(ball.getX() , 20 + ball.getSize());
                    return;
                }
                if ((ball.getY() >= 780) || (ball.getY() <= 800)) {
                    ball.setCenter(ball.getX() , 780 - ball.getSize());
                    return;
                }
                if ((ball.getX() >= 0) || (ball.getX() <= 20)) {
                    ball.setCenter(20 + ball.getSize() , ball.getY());
                    return;
                }
                if ((ball.getX() >= 580) || (ball.getX() <= 600)) {
                    ball.setCenter(580 - ball.getSize() , ball.getY());
                    return;
                }
            }
        }
    }

    /**
     * this method removing Collidable from the Collidable list.
     * @param c is the Collidable we want to remove.
     */
    public void removeCollidable(Collidable c) {
        colList.remove(c);
    }

    /**
     * this method id responsible that the ball won't stuck in the paddle.
     * @param b is the ball
     */
    public void fixStuckBall(Ball b) {
        if (colList.isEmpty()) {
            return;
        }
        for (Collidable collStuck : colList) {
            Rectangle colRect = collStuck.getCollisionRectangle();
            // get the collidable the ball is stuck in
            if (colRect.isContainPoint(b.getCenter())) {
                if (collStuck.getClass().getName() == "Sprites.Paddle") {
                    b.setCenter(b.getX(), 600 - 20
                            - 10 - b.getSize());
                    return;
                }
//                 set all closets points
                Point up = new Point(b.getX(), (int) colRect.getUpperLeft().getY() - b.getSize());
                Point low = new Point(b.getX(), (int) (colRect.getDownLeft(colRect.getUpperLeft() ,
                        colRect.getHeight()).getY() + b.getSize()));
                Point right = new Point((int) (colRect.getUpperRight(colRect.getUpperLeft() ,
                        colRect.getWidth()).getX() + b.getSize()), b.getY());
                Point left = new Point((int) colRect.getUpperLeft().getX() - b.getSize(), b.getY());

                // check if each point is stuck in another rectangle
                for (Collidable c : colList) {
                    if (!(c.getCollisionRectangle().isContainPoint(up))) {
                        b.setCenter(up.getX(), up.getY());
                        return;
                    }
                    if (!(c.getCollisionRectangle().isContainPoint(low))) {
                        b.setCenter(low.getX(), low.getY());
                        return;
                    }
                    if (!(c.getCollisionRectangle().isContainPoint(right))) {
                        b.setCenter(right.getX(), right.getY());
                        return;
                    }
                    if (!(c.getCollisionRectangle().isContainPoint(left))) {
                        b.setCenter(left.getX(), left.getY());
                        return;
                    }

                }
            }
        }
    }
}

