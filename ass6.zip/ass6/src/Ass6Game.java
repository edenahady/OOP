//ID 318948106

import biuoop.GUI;
import biuoop.Sleeper;

import java.util.ArrayList;
import java.util.List;

/**
 * creating the game class.
 */
public class Ass6Game {
    /**
     * This is the main function of the program.
     *
     * @param args - arguments of the program
     */
    public static void main(String[] args) {
        AnimationRunner animation = new AnimationRunner(new GUI("Arkanoid", 800, 600), 60, new Sleeper());
        List<LevelInformation> levels = new ArrayList<LevelInformation>();
        GameFlow gf = new GameFlow(animation, animation.getGui().getKeyboardSensor());
        for (String arg: args) {

            if (arg.equals("1")) {
                levels.add(new DirectHit());
            } else if (arg.equals("2")) {
                levels.add(new AllPink());
            } else if (arg.equals("3")) {
                levels.add(new WideEasy());
            } else if (arg.equals("4")) {
                levels.add(new BlueOcean());
            }
        }
        if (levels.isEmpty()) {
           levels.add(new DirectHit());
           levels.add(new AllPink());
           levels.add(new WideEasy());
           levels.add(new BlueOcean());
        }
        gf.runLevels(levels);
//        GameLevel game = new GameLevel();
//        game.initialize();
//        game.run();
    }

}
