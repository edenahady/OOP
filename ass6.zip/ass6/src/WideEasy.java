// ID: 318948106
import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 * creating WideEasy class.
 */
public class WideEasy implements LevelInformation {
    private int numberOfBalls;
    private List<Velocity> ballsVelocities;
    private int paddleSpeed;
    private int paddleWidth;
    private String levelName;
    private Sprite background;
    private List<Block> blocks;
    private int numberOfBlocksToRemove;
    private List<Ball> balls;

    /**
     * Constructor of Wide Easy level.
     */
    public WideEasy() {
        this.numberOfBalls = 10;
        this.ballsVelocities = new ArrayList<Velocity>();
        this.paddleSpeed = 4;
        this.paddleWidth = 650;
        this.levelName = "Wide Easy";
        this.background = new WideEasyBackground();
        this.blocks = new ArrayList<Block>();
        this.balls = new ArrayList<Ball>();

        // Create the blocks
        int x = 24;
        int y = 300;

        for (int i = 0; i < 15; i++) {
            Color blockColor;
            switch (i) {
                case 0:
                case 1:
                    blockColor = Color.RED;
                    break;
                case 2:
                case 3:
                    blockColor = Color.ORANGE;
                    break;
                case 4:
                case 5:
                    blockColor = Color.YELLOW;
                    break;
                case 6:
                case 7:
                case 8:
                    blockColor = Color.GREEN;
                    break;
                case 9:
                case 10:
                    blockColor = Color.BLUE;
                    break;
                case 11:
                case 12:
                    blockColor = Color.PINK;
                    break;
                case 13:
                case 14:
                    blockColor = Color.CYAN;
                    break;
                default:
                    blockColor = Color.BLACK;
                    break;
            }
            Rectangle rect = new Rectangle(new Point(x, y), 51, 30);
            Block block = new Block(rect, blockColor);
            this.blocks.add(block);
            x += 50;
        }
        this.numberOfBlocksToRemove = 15;

        int ballX = 350;
        int ballY = 350;

        // Create left side balls
        for (int i = this.numberOfBalls / 2; i >= 1; i--) {
            Ball ball = new Ball(ballX, ballY, 5, java.awt.Color.BLACK);
            this.balls.add(ball);
            ballX -= 50;
            ballY += 50 - i * 8;
        }

        ballX = 450;
        ballY = 350;

        // Create left side balls
        for (int i = this.numberOfBalls / 2; i >= 1; i--) {
            Ball ball = new Ball(ballX, ballY, 5, java.awt.Color.BLACK);
            this.balls.add(ball);
            ballX += 50;
            ballY += 50 - i * 8;
        }

        // Set left Balls Velocities
        for (int i = 330; i > 280; i -= 10) {
            this.ballsVelocities.add(Velocity.fromAngleAndSpeed(i, 5));
        }

        // Set right Balls Velocities
        for (int i = 30; i < 80; i += 10) {
            this.ballsVelocities.add(Velocity.fromAngleAndSpeed(i, 5));
        }

    }


    @Override
    public int numberOfBalls() {
        return this.numberOfBalls;
    }

    @Override
    public List<Velocity> initialBallVelocities() {
        return this.ballsVelocities;
    }

    @Override
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return this.paddleWidth;
    }

    @Override
    public String levelName() {
        return this.levelName;
    }

    @Override
    public Sprite getBackground() {
        return this.background;
    }

    @Override
    public List<Block> blocks() {
        return this.blocks;
    }

    @Override
    public List<Ball> balls() {
        this.balls = new ArrayList<Ball>();
        int ballX = 350;
        int ballY = 350;
        // Create left side balls
        for (int i = this.numberOfBalls / 2; i >= 1; i--) {
            Ball ball = new Ball(ballX, ballY, 5, java.awt.Color.BLACK);
            this.balls.add(ball);
            ballX -= 50;
            ballY += 50 - i * 8;
        }

        ballX = 450;
        ballY = 350;

        // Create left side balls
        for (int i = this.numberOfBalls / 2; i >= 1; i--) {
            Ball ball = new Ball(ballX, ballY, 5, java.awt.Color.BLACK);
            this.balls.add(ball);
            ballX += 50;
            ballY += 50 - i * 8;
        }
        return this.balls;
    }


    @Override
    public int numberOfBlocksToRemove() {
        return this.numberOfBlocksToRemove;
    }
}
