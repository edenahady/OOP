// ID: 318948106
/**
 * creating the Counter class.
 */
public class Counter {
    private int counter;

    /**
     * constructor to Counter.
     * @param val is the current number.
     */
    public Counter(int val) {
        this.counter = val;
    }

    /**
     * this method adds number to current count.
     * @param number is the number we adding
     */

    void increase(int number) {
        this.counter = this.counter + number;

    }

    /**
     * this method subtracts number from current count.
     * @param number is the number we decreasing
     */

    void decrease(int number) {
        this.counter = this.counter - number;
    }

    /**
     * this method returns the count.
     * @return count.
     */
    int getValue() {
        return this.counter;
    }
}
