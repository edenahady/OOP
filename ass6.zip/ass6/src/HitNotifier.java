//ID: 318948106
/**
 * creating the HitNotifier class.
 */
public interface HitNotifier {
    /**
     * Add hl as a listener to hit events.
     * @param hl is the HitListener.
     */

    void addHitListener(HitListener hl);

    /**
     * Remove hl from the list of listeners to hit events.
     * @param hl is the HitListener.
     */

    void removeHitListener(HitListener hl);
}
