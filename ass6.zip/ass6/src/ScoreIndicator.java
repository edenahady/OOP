//ID: 318948106
import biuoop.DrawSurface;
import java.awt.Color;

/**
 * creating the ScoreIndicator class.
 */
public class ScoreIndicator implements Sprite {
    private Counter score;
    private Rectangle rec;
    private Color color;

    /**
     * constructor to ScoreIndicator.
     * @param score is the given score.
     */
    public ScoreIndicator(Counter score) {
        this.score = score;
    }

    /**
     * constructor to ScoreIndicator.
     * @param score is the given score.
     * @param rec is the rectangle.
     * @param white is the color.
     */
    public ScoreIndicator(Counter score, Rectangle rec, Color white) {
        this.score = score;
        this.rec = rec;
        this.color = white;
    }

    @Override
    /**
     * this method adding the score to the screen.
     * @param d is the surface
     */
    public void drawOn(DrawSurface d) {
        d.setColor(new Color(210, 213, 219));
        d.fillRectangle(0, 0, 800, 20);
        d.setColor(Color.black);
        d.drawText(200, 17, "Score: " + String.valueOf(this.score.getValue()), 19);
    }

    @Override
    /**
     * this method notify that time has passed.
     */
    public void timePassed() {

    }

    /**
     * this method adding the sprite to the game.
     * @param game is our game.
     */
    public void addToGame(GameLevel game) {
        game.addSprite(this);
    }
}
