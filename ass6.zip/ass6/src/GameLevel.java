//ID 318948106

import java.awt.Color;
import java.awt.Point;
import java.util.List;
import java.util.Random;
import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import biuoop.Sleeper;

/**
 * creating the game class.
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private static int screenWidth = 800;
    private static int screenHeight = 600;
    private Counter blocksLeft;
    private Counter ballsLeft;
    private Counter score;
    private Counter lives;
    private Sleeper sleeper;
    private KeyboardSensor key;
    private AnimationRunner runner;
    private boolean running;
    private Paddle paddle;
    private LevelInformation levelInfo;
    private GameBoard gameBoard;

    /**
     * constructor to the game.
     */
//    public GameLevel() {
//        this.sprites = new SpriteCollection();
//        this.environment = new GameEnvironment();
//        this.gui = new GUI("Arkanoid", screenWidth, screenHeight);
//        this.sleeper = new Sleeper();
//        this.blocksLeft = new Counter(0);
//        this.ballsLeft = new Counter(3);
//        this.score = new Counter(0);
//        this.gameBoard = new GameBoard(runner.getGui(), screenHeight, screenWidth, 20, this.levelInfo.levelName());
////        this.running = true;
////        this.key = gui.getKeyboardSensor();
////        this.runner = new AnimationRunner(this.gui, this.a , this.sleeper );
//
//    }

    /**
     * constructor to GameLevel.
     * @param levelInfo is the information of the level
     * @param key is the keyboard sensor
     * @param animationRunner is what runs the animation
     * @param lives is the live of the block.
     * @param remainingBlocks is the number of block remains
     * @param remainingBalls is the number of balls remains
     * @param score is the score
     */
    public GameLevel(LevelInformation levelInfo, KeyboardSensor key , AnimationRunner animationRunner,
                     Counter lives, Counter remainingBlocks, Counter remainingBalls, Counter score) {
        this.environment = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.runner = animationRunner;
        this.key = key;
        this.blocksLeft = remainingBlocks;
        this.ballsLeft = remainingBalls;
        this.score = score;
        this.levelInfo = levelInfo;
        this.running = true;
        this.lives = lives;
        this.gameBoard = new GameBoard(runner.getGui(), screenHeight, screenWidth, 20, this.levelInfo.levelName());
//        this.gameBoard = new GameBoard(gui, screenHeight, screenWidth, 20, this.levelInfo.levelName());
//        this.gui = new GUI("Arkanoid", screenWidth, screenHeight);
        this.sleeper = new Sleeper();
    }

    /**
     * This method adds a Collidable object to the game.
     *
     * @param c is the Collidable
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * This method adds a Sprite object to the game.
     *
     * @param s is the Sprite
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * this method returns the number of hits we can hit the ball.
     * @return the number of hits we can hit the ball.
     */
    public Counter getLive() {
        return this.blocksLeft;
    }

    /**
     * This method initialize a new game.
     * creates the Blocks and Balls and Paddle into the game.
     */
    public void initialize() {
        HitListener blockRemover = new BlockRemover(this, this.blocksLeft);

        HitListener ballRemover = new BallRemover(this, this.ballsLeft);

        ScoreTrackingListener scoreTrackingListener = new ScoreTrackingListener(this.score);


        this.gameBoard.getBottom().addHitListener(ballRemover);


        this.addSprite(this.levelInfo.getBackground());

        this.gameBoard.addBordersToCollidable(this);

        this.addSprite(this.gameBoard);

        this.addBlocks(blockRemover , scoreTrackingListener);
        Rectangle rec = new Rectangle(new Point(0 , 0) , 400 , 20);
        ScoreIndicator scoreIndicator = new ScoreIndicator(this.score , rec , Color.cyan);
        Rectangle rectangleLevel = new Rectangle(new Point(400 , 0) , 400 , 20);
        LevelIndicator level = new LevelIndicator(rectangleLevel , Color.cyan , this.levelInfo);
        scoreIndicator.addToGame(this);
        level.addToGame(this);

//        blockRemover.setCounter(this.blocksLeft);

        this.paddle = new Paddle(Color.GRAY, this.gameBoard,
                new Rectangle(new Point(this.gameBoard.width() / 2 - (this.levelInfo.paddleWidth() / 2)
                        , this.gameBoard.height()
                        - (this.gameBoard.getMargin() * 2 + 10)),
                        this.levelInfo.paddleWidth(), 10), this.levelInfo.paddleSpeed());
        paddle.addToGame(this);
    }


    /**
     * This method runs the game -- starts the animation loop.
     */
    public void run() {
        this.createBallsOnTopOfPaddle(); // or a similar method

        this.runner.run(new CountdownAnimation(2, 3, this.sprites));
        if (this.blocksLeft.getValue() == 0) {
            this.running = false;

            return;
        }
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the game.
        this.runner.run(this);

//        this.createBallsOnTopOfPaddle(); // or a similar method
//        this.running = true;
//        // use our runner to run the current animation -- which is one turn of
//        // the game.
//        this.runner.run(this);
//        int framesPerSecond = 60;
//        int millisecondsPerFrame = 1000 / framesPerSecond;
//        while (true) {
//            long startTime = System.currentTimeMillis(); // timing
//            DrawSurface d = gui.getDrawSurface();
//            this.sprites.drawAllOn(d);
//            gui.show(d);
//            this.sprites.notifyAllTimePassed();
//            if (this.ballsLeft.getValue() == 0) {
//                gui.close();
//                break;
//
//            }
//            if (this.blocksLeft.getValue() == 0) {
//                this.score.increase(100);
//                String points = "Score: " + score.getValue();
//                System.out.println(points);
//                gui.close();
//                break;
//            }
//            // timing
//            long usedTime = System.currentTimeMillis() - startTime;
//            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
//            if (milliSecondLeftToSleep > 0) {
//                sleeper.sleepFor(milliSecondLeftToSleep);
//            }
//        }

    }

    /**
     * this method is setting the ball on top of the paddle.
     */

    private void createBallsOnTopOfPaddle() {
        List<Velocity> ballsVelocities = this.levelInfo.initialBallVelocities();
        List<Ball> balls = this.levelInfo.balls();

        for (int i = 0; i < this.levelInfo.numberOfBalls(); i++) {
            balls.get(i).setEnvironment(this.environment);
            balls.get(i).setVelocity(ballsVelocities.get(i));
            balls.get(i).addToGame(this);
            this.ballsLeft.increase(1);
        }

        // Create the paddle
//        this.paddle = new Paddle(this.key, this.levelInfo.paddleSpeed(), this.levelInfo.paddleWidth());
//        this.paddle.addToGame(this);
    }

    /**
     * @return random color.
     */
    public java.awt.Color findColor() {
        Random rand = new Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        Color randomColor = new Color(r, g, b); // sending random color
        return randomColor;
    }

    /**
     * this method removing Collidable from the game.
     * @param c is the Collidable we want to remove.
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * this method removing Sprite from the game.
     * @param s is the Sprite we want to remove.
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

//    /**
//     * @param args is unused here.
//     */
//    public static void main(String[] args) {
//        GameLevel game = new GameLevel();
//        game.initialize();
//        game.run();
//    }
    /**
     * This method draws the current state of the animation object on the screen.
     * @param d - the DrawSurface
     */
    @Override
    public void doOneFrame(DrawSurface d) {

        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed();

        if (this.key.isPressed("p")) {
            this.runner.run(new KeyPressStoppableAnimation(
                    this.key, "space", new PauseScreen(this.key)));
        }
//        int framesPerSecond = 60;
//        int millisecondsPerFrame = 1000 / framesPerSecond;

//        while (true) {
//            long startTime = System.currentTimeMillis(); // timing
//             d = gui.getDrawSurface();
//
//            gui.show(d);
//
//            if (this.ballsLeft.getValue() == 0) {
//                gui.close();
//                this.running = false;
//
//            }
//            if (this.blocksLeft.getValue() == 0) {
//                this.score.increase(100);
//                String points = "Score: " + score.getValue();
//                System.out.println(points);
//                gui.close();
//                this.running = false;
//            }
//            // timing
//            long usedTime = System.currentTimeMillis() - startTime;
//            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
//            if (milliSecondLeftToSleep > 0) {
//                this.sleeper.sleepFor(milliSecondLeftToSleep);
//            }
//        }
        if (ballsLeft.getValue() == 0) {
            running = false;
        }
        if ((blocksLeft.getValue() == 0)) {
            running = false;
        }
    }
    /**
     * adds the blpck to the game.
     *
     * @param blockRemover          the block remover listener.
     * @param scoreTrackingListener the score listener
     */

    public void addBlocks(HitListener blockRemover, ScoreTrackingListener scoreTrackingListener) {
        for (Block block : this.levelInfo.blocks()) {
            block.addToGame(this);
            block.addHitListener(blockRemover);
            block.addHitListener(scoreTrackingListener);
            //this.blocksLeft.increase(1);
        }
    }

    @Override
    public boolean shouldStop() {
    return !this.running;

    }
}
