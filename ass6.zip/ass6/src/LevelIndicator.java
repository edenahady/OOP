// ID: 318948106
import java.awt.Color;

/**
 * The type Level indicator.
 */
public class LevelIndicator implements Sprite {
    /**
     * The Rectangle.
     */
    private Rectangle rectangle;
    /**
     * The Color.
     */
    private Color color;
    /**
     * The Level information.
     */
    private LevelInformation levelInformation;

    /**
     * Instantiates a new Level indicator.
     *
     * @param rectangle        the rectangle
     * @param color            the color
     * @param levelInformation the level information
     */
    public LevelIndicator(Rectangle rectangle, Color color, LevelInformation levelInformation) {
        this.rectangle = rectangle;
        this.color = color;
        this.levelInformation = levelInformation;
    }

    /**
     * Draw on.
     *
     * @param d the d
     */
    @Override
    public void drawOn(biuoop.DrawSurface d) {
        int x = (int) this.rectangle.getUpperLeft().getX();
        int y = (int) this.rectangle.getUpperLeft().getY();
        int width = (int) this.rectangle.getWidth();
        int height = (int) this.rectangle.getHeight();
        String levelName = "Level Name : " + this.levelInformation.levelName();
        d.setColor(this.color);
        d.fillRectangle(x, y, width, height);
        d.setColor(Color.MAGENTA);
        d.drawText(x + (width / 2) - levelName.length() * 3, height - 3, levelName, 15);
    }

    /**
     * Time passed.
     */
    @Override
    public void timePassed() {

    }

    /**
     * Add to game.
     *
     * @param gameLevel the game level
     */
    public void addToGame(GameLevel gameLevel) {
        gameLevel.addSprite(this);
    }
}
