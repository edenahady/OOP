// ID: 318948106
import biuoop.DrawSurface;
import java.awt.Color;
/**
 * creating the AllPinkBackground class.
 */

public class AllPinkBackground implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {
        //background
        d.setColor(new Color(243, 168, 227));
        d.fillRectangle(0, 0, d.getWidth(), d.getHeight());

        //flowers
        for (int i = 0; i < 6; i++) {
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(270 + 100 * i, 550, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(230 + 100 * i, 550, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(250 + 100 * i, 530, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(250 + 100 * i, 570, 15);
            d.setColor(Color.white);
            d.fillCircle(250 + 100 * i, 550, 10);
        }

        for (int i = 0; i < 6; i++) {
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(770, 550 - 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(730, 550 - 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(750, 530 - 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(750, 570 - 95 * i, 15);
            d.setColor(Color.MAGENTA);
            d.fillCircle(750, 550 - 95 * i, 10);
        }

        for (int i = 0; i < 7; i++) {
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(770 - 100 * i, 75, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(730 - 100 * i, 75, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(750 - 100 * i, 55, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(750 - 100 * i, 95, 15);
            d.setColor(Color.pink);
            d.fillCircle(750 - 100 * i, 75, 10);

        }

        for (int i = 0; i < 6; i++) {
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(70, 75 + 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(30, 75 + 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(50, 55 + 95 * i, 15);
            d.setColor(new Color(234, 9, 186));
            d.fillCircle(50, 95 + 95 * i, 15);
            d.setColor(Color.CYAN);
            d.fillCircle(50, 75 + 95 * i, 10);
        }

        // the building
        d.setColor(new Color(200 , 128 , 255));
        d.fillRectangle(50, 410, 130, 190);
        d.setColor(new Color(200, 255, 255));

        // the windows
        int x = 60;
        int y = 420;
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 5; j++) {
                d.fillRectangle(x, y, 18, 27);
                x += 23;
            }
            d.setColor(new Color(204 + i * 10, 255, 255));

            x = 60;
            y += 33;
        }

        d.setColor(Color.MAGENTA);
        d.fillRectangle(98, 350, 35, 60);

        d.setColor(Color.pink);
        d.fillRectangle(110, 150, 10, 200);

        d.setColor(new Color(100, 200, 100));
        d.fillCircle(114, 145, 12);

        d.setColor(new Color(234, 90, 186));
        d.fillCircle(114, 145, 8);

        d.setColor(Color.lightGray);
        d.fillCircle(114, 145, 4);
    }

    @Override
    public void timePassed() {

    }
}
