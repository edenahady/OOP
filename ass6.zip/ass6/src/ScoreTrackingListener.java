//ID: 318948106
/**
 * creating the ScoreTrackingListener class.
 */
public class ScoreTrackingListener implements HitListener {
    private Counter currentScore;

    /**
     * constructor to ScoreTrackingListener.
     * @param scoreCounter is the current score.
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }
    @Override
    /**
     * this method notify that hit has happened.
     * @param beingHit is the block being Hit.
     * @parem hitter is the ball that hits the block.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
//        if (beingHit.getHealth() > 0) {
//            currentScore.increase(5);
//        }
        if (beingHit.getHealth() == 0) {
            currentScore.increase(5);
        }
    }
}
