// ID - 318948106

/**
 * creating a Point with X and Y.
 */
public class Point {
    private double x;
    private double y;

    // constructor

    /**
     * @param x is first coordination of the point.
     * @param y is second coordination of the point.
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }


    // distance -- return the distance of this point to the other point

    /**
     * this function gets a Point and returns the distance between this.point to the other point.
     *
     * @param other is the given Point which we want to check the distance to it
     * @return the distance between this point to the other point.
     */
    public double distance(Point other) {
        double power1 = Math.pow(this.x - other.getX(), 2);
        double power2 = Math.pow(this.y - other.getY(), 2);
        double dis = Math.sqrt(power1 + power2);
        return dis;
    }

    // equals -- return true if the points are equal, false otherwise

    /**
     * this function checks if this point equals to the other point, by checking their coordinates.
     *
     * @param other is the given Point which we want to check if it's equal to this.point
     * @return true if equals and false if not
     */
    public boolean equals(Point other) {
        if (this.x == other.getX() && this.y == other.getY()) {
            return true;
        }
        return false;
    }

    // Return the x and y values of this point

    /**
     * @return the y coordinate.
     */
    public double getX() {
        return this.x;
    }


    /**
     * @return the y coordinate.
     */
    public double getY() {
        return this.y;
    }

}
