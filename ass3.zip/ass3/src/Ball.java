//ID 318948106
import biuoop.DrawSurface;
//import java.awt.*;
import java.awt.Point;

/**
 * this class creates a ball.
 */
public class Ball implements Sprite {
    private Point center;
    private int x;
    private int y;
    private int r;
    private java.awt.Color color;
    private Velocity v;
    private GameEnvironment game;

    // constructor

    /**
     * constructor of a new ball created from a point, radios and color.
     *
     * @param center is the center point
     * @param r      is the radius of the ball
     * @param color  is the color of the ball
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0); // initialization

    }

    /**
     * constructor of a new ball from x of the center Point, y f the center Point, radios and color.
     *
     * @param x     is the x coordinate of the center point
     * @param y     is the y coordinate of the center point
     * @param r     is the radius of the ball
     * @param color is the color of the ball
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);

    }

    /**
     * @param x     is the x coordinate of the center point.
     * @param y     is the y coordinate of the center point
     * @param r     is the radius of the ball
     * @param color is the color of the ball
     * @param game  is the game
     */
    public Ball(int x, int y, int r, java.awt.Color color, GameEnvironment game) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
        this.v = new Velocity(0, 0);
        this.game = game;

    }

    /**
     * this method returns the x coordinate of the center point.
     *
     * @return the x coordinate of the center point
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * this method returns the y coordinate of the center point.
     *
     * @return the y coordinate of the center point
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * this method returns the radius of the ball.
     *
     * @return the radius of the ball
     */
    public int getSize() {
        return this.r;
    }

    /**
     * this method returns the color of the ball.
     *
     * @return the color of the ball
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * @return the game.
     */
    public GameEnvironment getGame() {
        return this.game;
    }

    // draw the ball on the given DrawSurface

    /**
     * this method is drawing the ball on the surface.
     *
     * @param surface is the board that we draw the ball on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(color);
        surface.fillCircle(this.getX(), this.getY(), this.r);

    }

    @Override
    /**
     * notify the ball that time has passed.
     *
     */
    public void timePassed() {
        this.moveOneStep();
        this.game.stuckProblem(this);
    }

    /**
     * this method add velocity to the ball.
     *
     * @param velocity the velocity that added to the ball
     */
    public void setVelocity(Velocity velocity) {
        this.v = velocity;
    }

    /**
     * this method returns the velocity of the ball.
     *
     * @return the velocity of the ball
     */

    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * @return the game envirinment.
     */
    public GameEnvironment getEnviorment() {
        return this.game;
    }

    /**
     * this method setting new game environment.
     *
     * @param g is the game environment.
     */
    public void setGameEnvironment(GameEnvironment g) {
        this.game = g;
    }

    /**
     * one of two same method that preventing the ball from disappear from the surface.
     *
     * @param width  is the width of the surface
     * @param height is the height of the surface
     */

    public void keepBallInBorders(int width, int height) {
        double nextX = this.center.getX() + this.v.getDx();
        double nextY = this.center.getY() + this.v.getDy();
        Velocity velocity = this.v;
        if (nextX + this.r > width || nextX - this.r < 0) {
            velocity = new Velocity(-this.v.getDx(), this.v.getDy());
        }
        if (nextY + this.r > height || nextY - this.r < 0) {
            velocity = new Velocity(this.v.getDx(), -this.v.getDy());
        }
        this.v = velocity;
    }

    /**
     * this method moved the ball using it velocity.
     */
    public void moveOneStep() {
        Velocity vel = this.getVelocity();
        if (vel != null) {
            this.keepBallInBorders(800, 600);
            if (this.game != null) {
                Point nextMove = vel.applyToPoint(this.center);
                Line trajectory = new Line(this.center, nextMove);
                CollisionInfo collisionInfo = this.game.getClosestCollision(trajectory);
                if (collisionInfo != null) {
                    this.setCenter(collisionInfo.collisionPoint().getX() - vel.getDx(),
                            collisionInfo.collisionPoint().getY() - vel.getDy());
                    Velocity newVelocity = collisionInfo.collisionObject().hit(collisionInfo.collisionPoint(), vel);
                    this.setVelocity(newVelocity);
                } else {
                    this.center = new Point(nextMove);
                }
            }
        }

    }

    /**
     * this method setting new center.
     *
     * @param x1 is the x coordination
     * @param y1 is the y coordination
     */
    public void setCenter(double x1, double y1) {
        this.center = new Point((int) x1, (int) y1);
    }

    /**
     * second of two same method that preventing the ball from disappear from the surface.
     *
     * @param wStart is the east border
     * @param hStart is the south border
     * @param wEnd   is the west border
     * @param hEnd   is the north border
     */
    public void keepBallInBorders(int wStart, int hStart, int wEnd, int hEnd) {
        double nextX = this.center.getX() + this.v.getDx();
        double nextY = this.center.getY() + this.v.getDy();
        Velocity velocity = this.v;
        if (nextX + this.r > wEnd || nextX - this.r < wStart) {
            velocity = new Velocity(-this.v.getDx(), this.v.getDy());
        }
        if (nextY + this.r > hEnd || nextY - this.r < hStart) {
            velocity = new Velocity(this.v.getDx(), -this.v.getDy());
        }
        this.v = velocity;
    }

    /**
     * @return the game environment.
     */
    public GameEnvironment getEnvironment() {
        return this.game;
    }

    /**
     * this method adding the sprite to the game.
     *
     * @param g is the game.
     */
    public void addToGame(Game g) {
        g.addSprite(this);
    }

    /**
     * @return the center.
     */
    public Point getCenter() {
        return this.center;
    }
}


