//ID 318948106

import java.awt.Point;

/**
 * creating the CollisionInfo class.
 */
public class CollisionInfo {
    private Point collPoint;
    private Collidable collObject;

    /**
     * @param collPoint  is our collision point.
     * @param collObject is the object we collide into
     */
    public CollisionInfo(Point collPoint, Collidable collObject) {
        this.collPoint = collPoint;
        this.collObject = collObject;
    }
    // the point at which the collision occurs.

    /**
     * @return the collision point.
     */
    public Point collisionPoint() {
        return collPoint;
    }

    // the collidable object involved in the collision.

    /**
     * @return return the object we collide into.
     */
    public Collidable collisionObject() {
        return collObject;
    }
}
