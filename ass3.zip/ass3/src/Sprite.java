// ID - 318948106

import biuoop.DrawSurface;

/**
 * creating the sprite interface.
 */
public interface Sprite {
    // draw the sprite to the screen

    /**
     * this method is drawing the sprite on the surface.
     *
     * @param d is our surface.
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     */
    void timePassed();
}
