// ID - 318948106

import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;

/**
 * creating the SpriteCollection class.
 */
public class SpriteCollection {
    private DrawSurface d;
    private List<Sprite> sprites;

    /**
     * constructor.
     */
    public SpriteCollection() {
        this.sprites = new ArrayList<Sprite>();
    }

    /**
     * this method adding the sprite to the list.
     *
     * @param s is the sprite.
     */
    public void addSprite(Sprite s) {
        this.sprites.add(s);
    }

    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        for (Sprite sprite : sprites) {
            sprite.timePassed();
        }
    }

    /**
     * call drawOn(d) on all sprites.
     *
     * @param d1 is our surface.
     */
    public void drawAllOn(DrawSurface d1) {
        for (Sprite sprite : sprites) {
            sprite.drawOn(d1);
        }

    }

}