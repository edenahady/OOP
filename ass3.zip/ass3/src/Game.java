//ID 318948106

import java.awt.Color;
import java.awt.Point;
import java.util.Random;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * creating the game class.
 */
public class Game {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private static int screenWidth = 800;
    private static int screenHeight = 600;
    private GUI gui;
    private Sleeper sleeper;

    /**
     * constructor to the game.
     */
    public Game() {
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.gui = new GUI("Arkanoid", screenWidth, screenHeight);
        this.sleeper = new Sleeper();
    }

    /**
     * This method adds a Collidable object to the game.
     *
     * @param c is the Collidable
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * This method adds a Sprite object to the game.
     *
     * @param s is the Sprite
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * This method initialize a new game.
     * creates the Blocks and Balls and Paddle into the game.
     */
    public void initialize() {

        /* creates the bounding blocks and draws them */
        Block leftBound = new Block(new Point(0, 0), 20, screenHeight);
        Block rightBound = new Block(
                new Point(screenWidth - 20, 20), 20, screenHeight);
        Block upBound = new Block(new Point(0, 0), screenWidth, 20);
        Block lowBound = new Block(
                new Point(0, screenHeight - 20), screenWidth, 20);

        Block[] bounds = new Block[4];
        bounds[0] = leftBound;
        bounds[1] = rightBound;
        bounds[2] = upBound;
        bounds[3] = lowBound;

        for (Block b : bounds) {
            b.setColor(Color.darkGray);
//            bounds[i].addToGame(this.environment);
            b.addToGame(this);
        }

        /* creates the balls */
        Ball ball1 = new Ball(screenWidth / 2,
                screenHeight / 2 + 100, 5, Color.magenta);
        ball1.setVelocity(Velocity.fromAngleAndSpeed(45, 5));
        ball1.setGameEnvironment(this.environment);
        this.addSprite(ball1);

        Ball ball2 = new Ball(screenWidth / 2 + 50,
                screenHeight / 2 + 200, 5, Color.orange);
        ball2.setVelocity(Velocity.fromAngleAndSpeed(45, 5));
        ball2.setGameEnvironment(this.environment);
        this.addSprite(ball2);

        /* creates the blocks */
        for (int i = 0; i < 6; i++) {
            Color c = findColor();
//            Color c= Color.YELLOW;
            for (int j = 0; j < 12 - i; j++) {
                int hit = 1;
                if (i == 0) {
                    hit = 2;
                }
                int blockH = 30;
                int blockW = 55;
                Point p = new Point(screenWidth - 20 - (j + 1) * blockW,
                        120 + blockH * i);
                Block b = new Block(p, blockW, blockH);
                b.setHealth(hit);
                b.setColor(c);
//                System.out.println(c.toString());
//                b.addToGame(this.environment);
                b.addToGame(this);

            }
        }
        Paddle pad = new Paddle(this.gui, screenWidth, screenHeight);
        pad.addToGame(this);
    }


    /**
     * This method runs the game -- starts the animation loop.
     */
    public void run() {

        int framesPerSecond = 60;
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing

            DrawSurface d = gui.getDrawSurface();
            this.sprites.drawAllOn(d);
            gui.show(d);
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }

    }

    /**
     * @return random color.
     */
    public java.awt.Color findColor() {
        Random rand = new Random();
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        Color randomColor = new Color(r, g, b); // sending random color
        return randomColor;
    }

    /**
     * @param args is unused here.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
