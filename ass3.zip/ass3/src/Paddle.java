// ID - 318948106

import biuoop.DrawSurface;
import biuoop.GUI;
import java.awt.Color;
import java.awt.Point;

/**
 * creating the paddle class.
 */
public class Paddle implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private static int width = 150;
    private static int height = 20;
    private Rectangle rect;
    private java.awt.Color color;
    private int screenWidth;


    /**
     * Constructor of paddle.
     *
     * @param gui the keyboard sensor
     * @param screenWidth is the width of the screen.
     * @param screenHeight is the height of the screen.
     */
    public Paddle(GUI gui, int screenWidth, int screenHeight) {
        this.screenWidth = screenWidth;
        Point p = new Point((this.screenWidth - width) / 2,
                screenHeight - 2 * height);
//        Point p = new Point(380, screenHeight -40);
        this.rect = new Rectangle(p, width, height);
        this.keyboard = gui.getKeyboardSensor();
        this.color = java.awt.Color.pink;
    }

    /**
     * this method moving the paddle to the left.
     */

    public void moveLeft() {
        double x, y;
        x = this.rect.getUpperLeft().getX() - 5;
        y = this.rect.getUpperLeft().getY();
//        if (x < 20) {
//            x = 20;
//        }
        if (x < 20) {
            x = screenWidth - (this.rect.getWidth() + 20);
        }
        this.rect = new Rectangle(new Point((int) x, (int) y), width, height);
    }

    /**
     * this method moving the paddle to the left.
     */

    public void moveRight() {
        double x, y;
        x = this.rect.getUpperLeft().getX() + 5;
        y = this.rect.getUpperLeft().getY();
        if (x + width >= this.screenWidth - 20) {
            x = this.width - (this.rect.getWidth() - 20);
        }
        this.rect = new Rectangle(new Point((int) x, (int) y), width, height);

    }

    @Override
    /**
     * this method is drawing the paddle on the screen.
     */
    public void drawOn(DrawSurface d) {
        int xVal = (int) rect.getUpperLeft().getX();
        int yVal = (int) rect.getUpperLeft().getY();
        int wid = (int) rect.getWidth();
        int hei = (int) rect.getHeight();

        d.setColor(Color.pink);
        d.fillRectangle(xVal, yVal, wid, hei);
        d.setColor(Color.black);
        d.drawRectangle(xVal, yVal, wid, hei);
    }

    /**
     * this method notify the paddle that time has passed.
     */
    public void timePassed() {
        if (this.keyboard.isPressed(keyboard.LEFT_KEY)) {
            this.moveLeft();
        } else if (this.keyboard.isPressed(keyboard.RIGHT_KEY)) {
            this.moveRight();
        }
    }

    /**
     * @return te rectangle.
     */
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }


    /**
     * The paddle divided to 5 areas, this function checks in which area the ball hit the paddle.
     *
     * @param collisionPoint - the collision point of the ball with the paddle
     * @param currentVelocity is the currrent velocity of the ball.
     * @return the collision area - in range 1 - 5 .
     */

    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        double paddleX = this.rect.getUpperLeft().getX();
        double colX = collisionPoint.getX();
        double paddlePart = (width / 5);
        double speed = Math.sqrt(Math.pow(currentVelocity.getDx(), 2)
                + Math.pow(currentVelocity.getDy(), 2));
        if (colX <= paddlePart + paddleX) {
            return Velocity.fromAngleAndSpeed(300, speed);
        }
        if (colX <= 2 * paddlePart + paddleX) {
//            return new Velocity(currentVelocity.getDx(),
//                    -currentVelocity.getDy());
            return Velocity.fromAngleAndSpeed(330, speed);
        }
        if (colX <= 3 * paddlePart + paddleX) {
            return new Velocity(currentVelocity.getDx(),
                    -currentVelocity.getDy());
        }
        if (colX <= 4 * paddlePart + paddleX) {
            return Velocity.fromAngleAndSpeed(30, speed);
        }
        return Velocity.fromAngleAndSpeed(60, speed);
    }

    // Add this paddle to the game.

    /**
     * this method adding this paddle to the game.
     *
     * @param g is the game.
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }

}
