// ID - 318948106
import java.awt.Point;
import java.util.List;

/**
 * creates a line.
 * a class creates a line from 2 points.
 * it has private start point, from there the line is starting.
 * it has private end point, where the line is ending.
 */
public class Line {
    private Point start;
    private Point end;

    // constructors

    /**
     * @param start from there the line is starting.
     * @param end   where the line is ending.
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }

    /**
     * @param x1 is the first coordinate of the start point.
     * @param y1 is the second coordinate of the start point.
     * @param x2 is the first coordinate of the end point.
     * @param y2 is the second coordinate of the end point.
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point((int) x1, (int) y1);
        this.end = new Point((int) x2, (int) y2);
    }

    // Return the length of the line

    /**
     * calculate the length of the line from the distance of the 2 points using Point class.
     *
     * @return the length of the line.
     */
    public double length() {
        double len = this.start.distance(this.end);
        return len;
    }

    // Returns the middle point of the line

    /**
     * calculate the middle point of the line.
     *
     * @return the middle point
     */
    public Point middle() {
        double xMid = (this.start.getX() + this.end.getX()) / 2;
        double yMid = (this.start.getY() + this.end.getY()) / 2;
        Point mid = new Point((int) xMid, (int) yMid);
        return mid;
    }

    // Returns the start point of the line

    /**
     * @return the start point.
     */
    public Point start() {
        return this.start;
    }

    // Returns the end point of the line

    /**
     * @return the end point.
     */
    public Point end() {
        return this.end;
    }

    // Returns true if the lines intersect, false otherwise

    /**
     * @param other is the given line that we check on it if it's intersecting with this.line.
     * @return true if they are intersecting, false if not
     */
    public boolean isIntersecting(Line other) {
        Point check = intersectionWith(other);
        if (check == null) {
            return false;
        } else {
            double xMax = Math.max(this.start.getX(), this.end.getX());
            double yMax = Math.max(this.start.getY(), this.end.getY());
            double xMin = Math.min(this.start.getX(), this.end.getX());
            double yMin = Math.min(this.start.getY(), this.end.getY());
            if (check.getX() >= xMin && check.getX() <= xMax && check.getY() >= yMin && check.getY() <= yMax) {
                return true;
            }
            return false;

        }

    }

    /**
     * @param start1 is the point that we check if it's in the range of start2 end end2.
     * @param start2 start point of the line
     * @param end2   end point of the line
     * @return if the start1 is in the range of the line
     */
    public boolean contains(Point start1, Point start2, Point end2) {
        double xMax = Math.max(start2.getX(), end2.getX());
        double yMax = Math.max(start2.getY(), end2.getY());
        double xMin = Math.min(start2.getX(), end2.getX());
        double yMin = Math.min(start2.getY(), end2.getY());
        return start1.getX() >= xMin && start1.getX() <= xMax && start1.getY() >= yMin && start1.getY() <= yMax;
    }

    // Returns the intersection point if the lines intersect,
    // and null otherwise.

    /**
     * @param other is the given line that we check if it's intersects with this.line.
     * @return the intersection point if the lines intersect, and null otherwise.
     */
    public Point intersectionWith(Line other) {
        double m = 0;
        double n = 0;
        double mOther = 0;
        double nOther = 0;
        double xInter = 0;
        double yInter = 0;
        double decX;
        double decY;
        double decXOther;
        double decYOther;
        if (this.start.equals(this.end) && other.start.equals(other.end)) { // if there are two different points
            if (this.start.getX() != other.start.getX() || this.start.getY() != other.start.getY()) {
                return null;
            }
        }
        if (this.start.equals(this.end) && other.start.equals(other.end)) { // if there are two equal points
            if (this.start.equals(other.start)) {
                return this.start;
            }
        }

        if (this.start.equals(this.end) && !other.start.equals(other.end)) {
            // if we got a dot
            if (contains(this.start, other.start, other.end)) {
                decXOther = other.start.getX() - other.end.getX();
                decYOther = other.start.getY() - other.end.getY();
                // finding the incline between start and end
                mOther = decYOther / decXOther;
                if (decXOther == 0) {
                    if (this.start.getX() == other.start.getX()) {
                        return this.start;
                    }
                    return null;
                }
                nOther = other.start.getY() - (mOther * other.start.getX());
                // finding the free variable
                if (this.start.getY() == (mOther * this.start.getX() + nOther)) {
                    return this.start;
                } else {
                    return null;
                }
            }
            return null;
        }
        if (other.start.equals(other.end) && !this.start.equals(this.end)) {
            // if we got a dot
            if (contains(other.start, this.start, this.end)) {
                decX = this.start.getX() - this.end.getX();
                decY = this.start.getY() - this.end.getY();
                // finding the incline between start and end
                m = decY / decX;
                // finding the incline between start and end
                if (decX == 0) {
                    if (other.start.getX() == this.start.getX()) {
                        return other.start;
                    }
                    return null;
                }
                n = this.start.getY() - (m * this.start.getX());
                // finding the free variable
                if (other.start.getY() == (m * other.start.getX() + n)) {
                    return other.start;
                } else {
                    return null;
                }
            }
            return null;
        }
        decX = this.start.getX() - this.end.getX();
        decY = this.start.getY() - this.end.getY();
        // now we do the same for Line other
        decXOther = other.start.getX() - other.end.getX();
        decYOther = other.start.getY() - other.end.getY();
        if (decX == 0 && decXOther == 0) { // if we have to lines that parallel to y axis
            if (this.start.getX() != other.start.getX()) {
                return null;
            }
            if (this.start.getX() == other.start.getX()) { // one line containing the other
                if (contains(other.start, this.start, this.end) || contains(other.end, this.start, this.end)) {
                    return null;
                }
                if (this.start.equals(other.end) || this.start.equals(other.start)) {
                    return this.start;
                }
                if (this.end.equals(other.start) || this.end.equals(other.end)) {
                    return this.end;
                }

            }
        }
        // if one line is parallel to y axis and the other line is normal
        if (decX == 0) {
            double intersectionX = this.start.getX();
            mOther = decYOther / decXOther;
            nOther = other.start.getY() - (mOther * other.start.getX());
            double intersectionY = mOther * intersectionX + nOther;
            Point intersectionP = new Point((int) intersectionX, (int) intersectionY);
            if ((this.contains(intersectionP, this.start, this.end)
                    && (other.contains(intersectionP, other.start, other.end)))) {
                return intersectionP;
            }
            return null;
        }
        if (decXOther == 0) {
            double intersectionX = other.start.getX();
            m = decY / decX;
            n = this.start.getY() - (m * this.start.getX());
            double intersectionY = m * intersectionX + n;
            Point intersectionP = new Point((int) intersectionX, (int) intersectionY);
            if ((this.contains(intersectionP, this.start, this.end)
                    && (other.contains(intersectionP, other.start, other.end)))) {
                return intersectionP;
            }
            return null;
        }

        m = decY / decX;
        // finding the incline between start and end
        mOther = decYOther / decXOther;
        // finding the incline between start and end
        if (m == mOther) {
            return null;
        }
        n = this.start.getY() - (m * this.start.getX());
        // finding the free variable

        nOther = other.start.getY() - (mOther * other.start.getX());
        // finding the free variable

        xInter = (nOther - n) / (m - mOther); // finding the x of the intersection point
        yInter = (m * xInter) + n;  // finding the y of the intersection point
        Point inter = new Point((int) xInter, (int) yInter);
        if (contains(inter, this.start, this.end) && contains(inter, other.start, other.end)) {
            return inter;
        }
        return null;
    }

    // equals -- return true is the lines are equal, false otherwise

    /**
     * @param other is the given line that we check if it's equals to this.line.
     * @return true is the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        if ((this.start.equals(other.start) && this.end.equals(other.end))
                || (this.start.equals(other.end) && this.end.equals(other.start))) {
            return true;

        }
        return false;
    }

    /**
     * @param rect is the rectangle.
     * @return the closest intersection to start of the line from rectangle.
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        List<Point> intrsPoints = rect.intersectionPoints(this);
        if (!intrsPoints.isEmpty()) {
            if (intrsPoints.size() == 1) {
                return intrsPoints.get(0);
            } else {
                if (intrsPoints.size() == 2) {
                    double a = this.start.distance(intrsPoints.get(0));
                    double b = this.start.distance(intrsPoints.get(1));
                    if (a > b) {
                        return intrsPoints.get(1);
                    } else {
                        return intrsPoints.get(0);
                    }
                } else {
                    for (Point point : intrsPoints) {
                        double a = this.start.distance(intrsPoints.get(0));
                        double b = this.start.distance(point);
                        Point closest = intrsPoints.get(0);
                        if (a > b) {
                            closest = point;
                        }
                        return closest;
                    }
                }
            }
        }
        return null;
    }

    /**
     * @param point is the point we check if it is in the line.
     * @return true if the point is in the line, else false.
     */
    public boolean isPointInLine(Point point) {
        if (this.start.getX() == this.end.getX()) {
            return (point.getX() == this.start.getX()
                    && ((point.getY() >= this.start.getY() && point.getY() <= this.end.getY())
                    || (point.getY() <= this.start.getY() && point.getY() >= this.end.getY())));
        }
        double decX = this.start.getX() - this.end.getX();
        double decY = this.start.getY() - this.end.getY();
        double m = decY / decX;
        double n = this.start.getY() - (m * this.start.getX());
        if (decX == 0) {
            n = this.start.getY();
        }
        double pointY =  m * point.getX() + n;
        if (Math.round(pointY * 10000) != Math.round(point.getY() * 10000)) {
            return false;
        }

        return (point.getY() == m * point.getX() + n);
    }
}
