//ID 318948106

import java.util.ArrayList;
import java.util.List;
import java.awt.Point;

/**
 * creating the game environment class.
 */
public class GameEnvironment {
    private List<Collidable> colList;

    /**
     * constructor to game environment.
     */
    public GameEnvironment() {
        this.colList = new ArrayList<Collidable>();
    }

    /**
     * this method adding the given collidable to the environment.
     *
     * @param c is the collidable we want to add.
     */
    public void addCollidable(Collidable c) {
        colList.add(c);
    }

    /**
     * @return the list of collidables.
     */
    public List<Collidable> getColList() {
        return colList;
    }

    // Assume an object moving from line.start() to line.end().
    // If this object will not collide with any of the collidables
    // in this collection, return null. Else, return the information
    // about the closest collision that is going to occur.

    /**
     * @param trajectory is the line.
     * @return the closest collision point.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        CollisionInfo collisionInfo = null;
        for (Collidable collidable : colList) {
            Rectangle rect = collidable.getCollisionRectangle();
            Point closestPoint = trajectory.closestIntersectionToStartOfLine(rect);
//            System.out.println(closestPoint.toString());
            if (closestPoint != null) {
                collisionInfo = new CollisionInfo(closestPoint, collidable);
                break;
            }
        }
        return collisionInfo;

    }

    /**
     * this method gets a ball and checks if it got stuck in
     * a collidable object. if so, resets it's location
     * to the bottom of the screen.
     * @param ball the given ball.
     */
//    public void stuckProblem(Ball ball) {
//        Random random = new Random();
//        if (this.colList.isEmpty()) {
//            return;
//        }
//        for (Collidable obj : colList) {
//            if (obj.getCollisionRectangle().
//                    isContainPoint(ball.getCenter())) {
//                ball.setCenter(350 + random.nextInt(100), 450);
//
//            }
//        }
//    }
    public void stuckProblem(Ball ball) {
        if (colList.isEmpty()) {
            return;
        }
        for (Collidable collStuck : colList) {
            Rectangle colRect = collStuck.getCollisionRectangle();
            // get the collidable the ball is stuck in
            if (colRect.isContainPoint(ball.getCenter())) {
                if (collStuck.getClass().getName() == "Paddle") {
                    ball.setCenter(ball.getX(), 600 - 20
                            - 20 - ball.getSize());
                    return;
                }
                if ((ball.getY() >= 0) || (ball.getY() <= 20)) {
                    ball.setCenter(ball.getX() , 20 + ball.getSize());
                    return;
                }
                if ((ball.getY() >= 780) || (ball.getY() <= 800)) {
                    ball.setCenter(ball.getX() , 780 - ball.getSize());
                    return;
                }
                if ((ball.getX() >= 0) || (ball.getX() <= 20)) {
                    ball.setCenter(20 + ball.getSize() , ball.getY());
                    return;
                }
                if ((ball.getX() >= 580) || (ball.getX() <= 600)) {
                    ball.setCenter(580 - ball.getSize() , ball.getY());
                    return;
                }
            }
        }
    }
}
