//ID 318948106

/**
 * creating the game class.
 */
public class Ass3Game {
    /**
     * This is the main function of the program.
     *
     * @param args - arguments of the program
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }

}
