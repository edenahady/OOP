// ID - 318948106

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 * creates the rectangle class.
 */
public class Rectangle {
    private Point upperLeft;
    private double width;
    private double height;
    private Point upperRight;
    private Point downLeft;
    private Point downRight;

    // Create a new rectangle with location and width/height.

    /**
     * this method is constructor that creates a new rectangle with location and width/height.
     *
     * @param upperLeft is the upper left point
     * @param width     is the width of the screen
     * @param height    is the height of the screen
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
        upperRight = getUpperRight(upperLeft, width);
        downLeft = getDownLeft(upperLeft, height);
        downRight = getDownRight(upperLeft, width, height);


    }

    /**
     * this method is constructor that creates a rectangle with 4 points.
     *
     * @param upperLeft  is the upper left point
     * @param upperRight is the upper right point
     * @param downLeft   is the downer left point
     * @param downRight  is the downer right point
     */
    public Rectangle(Point upperLeft, Point upperRight, Point downLeft, Point downRight) {
        this.upperLeft = upperLeft;
        this.upperRight = upperRight;
        this.downLeft = downLeft;
        this.downRight = downRight;
    }

    // Return a (possibly empty) List of intersection points
    // with the specified line.

    /**
     * @param line is the line that we check the intersection point with.
     * @return the list of intersection points.
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        Line left = new Line(upperLeft, downLeft);
        Line right = new Line(upperRight, downRight);
        Line up = new Line(upperLeft, upperRight);
        Line down = new Line(downLeft, downRight);
        List<Point> points = new ArrayList<Point>();

        if (line.intersectionWith(left) != null) {
            points.add(line.intersectionWith(left));
        }
        if (line.intersectionWith(right) != null) {
            points.add(line.intersectionWith(right));
        }
        if (line.intersectionWith(up) != null) {
            points.add(line.intersectionWith(up));
        }
        if (line.intersectionWith(down) != null) {
            points.add(line.intersectionWith(down));
        }
        return points;


//        List<Point> optinals = new ArrayList<Point>(2);
//        Rectangle rect = new Rectangle(upperLeft , upperRight , downLeft , downRight);
//        for (int i = 0; i < optinals.size(); i++){
//            optinals.add(line.closestIntersectionToStartOfLine(rect));
//        }
//
//        return optinals;
    }


    /**
     * @return the width and height of the rectangle.
     */
    public double getWidth() {
        return this.width;
    }

    /**
     * @return the height and height of the rectangle.
     */
    public double getHeight() {
        return this.height;
    }

    /**
     * @return the upper left point of the rectangle.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * @param uppLeft is the upper left point of the rectangle.
     * @param width1  is width of the screen.
     * @return the upper right point of the rectangle.
     */
    public Point getUpperRight(Point uppLeft, double width1) {
        double x = uppLeft.getX() + width1;
        double y = uppLeft.getY();
        Point uppRight = new Point((int) x, (int) y);
        return uppRight;
    }

    /**
     * @param uppLeft is the upper left point of the rectangle.
     * @param h is height of the screen.
     * @return the downer left of the rectangle.
     */
    public Point getDownLeft(Point uppLeft, double h) {
        double y = uppLeft.getY() + h;
        double x = uppLeft.getX();
        Point downerLeft = new Point((int) x, (int) y);
        return downerLeft;
    }

    /**
     * @param uppLeft is the upper left point of the rectangle.
     * @param w  is width of the screen.
     * @param h  is height of the screen.
     * @return the downer right of the rectangle.
     */
    public Point getDownRight(Point uppLeft, double w, double h) {
        double x = uppLeft.getX() + w;
        double y = uppLeft.getY() + h;
        Point downerRight = new Point((int) x, (int) y);
        return downerRight;
    }

    /**
     * @return the dunes of the rectangle.
     */
    public java.util.List<Line> getDune() {
        List<Line> dune = new ArrayList<Line>();
        dune.add(new Line(this.upperLeft, this.getUpperRight(upperLeft, width)));
        dune.add(new Line(this.upperLeft, this.getDownLeft(upperLeft, height)));
        dune.add(new Line(this.getDownLeft(upperLeft, height), this.getDownRight(upperLeft, width, height)));
        dune.add(new Line(this.getUpperRight(upperLeft, width), this.getDownRight(upperLeft, width, height)));
        return dune;
    }

    /**
     * this method checks if a given point is this rectangle area.
     *
     * @param point the given point.
     * @return true if the point is in the rectangle's area, false otherwise.
     */
    public boolean isContainPoint(Point point) {
        return point.getX() > this.getUpperLeft().getX()
                && point.getX() < this.getUpperRight(upperLeft, width).getX()
                && point.getY() > this.getUpperLeft().getY()
                && point.getY() < this.getDownLeft(upperLeft, height).getY();
    }


}
