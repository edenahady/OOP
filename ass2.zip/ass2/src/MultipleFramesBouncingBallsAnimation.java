// ID 318948106
import java.awt.*;
import java.util.Random;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.*;
import java.util.Random;

/**
 * This class creates the type multiple frames bouncing balls animation.
 */
public class MultipleFramesBouncingBallsAnimation {
    Random rand = new Random(); // create a random-number generator

    /**
     * this method creates the animation.
     * @param b is the balls array
     */
    public void drawTheFirstFrame(Ball[] b) {
        biuoop.GUI gui = new biuoop.GUI("Multiple Bouncing Balls Frame 1", 600, 600);
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        while (true) {
            biuoop.DrawSurface d = gui.getDrawSurface();
            d.setColor(Color.gray); // creating the rectangles frames 
            d.fillRectangle(50, 50, 450, 450);
            d.setColor(Color.yellow);
            d.fillRectangle(450, 450, 150, 150);
            for (int i = 0; i < b.length; i++) {
                if (i >= b.length / 2) {
                    b[i].keepBallInBorders(450, 450, 600, 600);
                    b[i].moveOneStep();
                    b[i].drawOn(d);
                }
                else {
                    b[i].keepBallInBorders(50, 50, 500, 500);
                    b[i].moveOneStep();
                    b[i].drawOn(d);
                }
            }
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.

        }
    }

    /**
     * this method creates the balls array and setting velocities to the balls.
     * @param radiuses is the radiuses array
     * @return the ball array
     */
    public Ball[] createBallsArray(int[] radiuses) {
        int x;
        int y;
        Ball[] balls = new Ball[radiuses.length];
        for (int i = 0; i < balls.length; ++i) {
            if (i < balls.length / 2) {
                 x = rand.nextInt(450 - (2 * radiuses[i])) + 50 + radiuses[i];
                 // borders of the balls in the first frame
                 y = rand.nextInt(450 - (2 * radiuses[i])) + 50 + radiuses[i];
            }
            else {
                x = rand.nextInt(150 - (2 * radiuses[i])) + 450 + radiuses[i];
                // borders of the balls in the second frame
                y = rand.nextInt(150 - (2 * radiuses[i])) + 450 + radiuses[i];
            }
            int r = radiuses[i];
            balls[i] = new Ball(x , y , r , findColor());
            double speed = 50 / r;
            if (speed <= 1) {
                speed = 1;
            }
            if (r >= 50) {
                speed = 5;
            }
            double angle = rand.nextInt(360);
            Velocity v = Velocity.fromAngleAndSpeed(angle , speed);
            balls[i].setVelocity(v);
        }
        return balls;
    }

    /**
     * this method return random color.
     * @return random color.
     */
    public java.awt.Color findColor() {
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        Color randomColor = new Color(r, g, b); // sending random color
        return randomColor;
    }

    /**
     * this is the main method.
     * @param args is the radiuses given from the user
     */
    public static void main(String[] args) {

        if (args.length < 6) {
            return;
        }
        int[] radiuses = new int[args.length];
        for (int i = 0; i < radiuses.length; i++) {
            radiuses[i] = Integer.parseInt(args[i]); // creating the radiuses array
            if (radiuses[i] >= 300) {
                System.out.println("Choose radius size smaller than 300"); // the radius is too big
                radiuses[i] = Integer.parseInt(args[i]);
            }
        }
        MultipleFramesBouncingBallsAnimation example = new MultipleFramesBouncingBallsAnimation();
        Ball[] balls = example.createBallsArray(radiuses);
        example.drawTheFirstFrame(balls);

    }
}


