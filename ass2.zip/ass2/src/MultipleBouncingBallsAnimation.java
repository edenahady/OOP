import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;
import java.awt.*;
import java.util.Random;

/**
 * this class creates animation of multiple Bouncing Balls.
 */
public class MultipleBouncingBallsAnimation {
    private int width = 200;
    private int height = 200;
    Random rand = new Random(); // create a random-number generator

    /**
     * this method is creating the animation.
     * @param b is the balls array
     */
    public void drawTheBall(Ball[] b) {
        biuoop.GUI gui = new biuoop.GUI("Multiple Bouncing Balls" , width , height);
        biuoop.Sleeper sleeper = new biuoop.Sleeper();
        while (true) {
            biuoop.DrawSurface d = gui.getDrawSurface();
            for (int i = 0; i < b.length; i++) {
                b[i].keepBallInBorders(width , height);
                b[i].moveOneStep();
                b[i].drawOn(d);
            }
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.

        }


    }

    /**
     * this method creating the balls array with x and y coordination, radius and color and setting the ball velocity.
     * @param radiuses is the radiuses array
     * @return the balls array
     */
    public Ball[] createBallsArray(int[] radiuses) {
        Ball[] balls = new Ball[radiuses.length];
        for (int i = 0; i < balls.length; ++i) {
            int x = rand.nextInt(width);
            int y = rand.nextInt(height);
            int r = radiuses[i];
            balls[i] = new Ball(x , y , r , findColor());
            double speed = 50 / r;
            if (speed <= 1) {
                speed = 1;
            }
            if (r >= 50) { // if the ball is larger than 50 set a permanent speed
                speed = 5;// maximum speed
            }
            double angle = rand.nextInt(360);
            Velocity v = Velocity.fromAngleAndSpeed(angle , speed);
            balls[i].setVelocity(v);
        }
        return balls;
    }

    /**
     * this method returns random color.
     * @return random color
     */
    public java.awt.Color findColor() {
        float r = rand.nextFloat();
        float g = rand.nextFloat();
        float b = rand.nextFloat();
        Color randomColor = new Color(r, g, b); // sending random color
        return randomColor;
    }

    /**
     * this is the main method.
     * @param args is the radiuses given from the user
     */
    public static void main(String[] args) {
        if (args.length < 6) {
            return;
        }
        int[] radiuses = new int[args.length];
        for (int i = 0; i < radiuses.length; i++) { // creating the radiuses array
            radiuses[i] = Integer.parseInt(args[i]);
            if(radiuses[i] >= 100) {
                System.out.println("Choose radius size smaller than 100");
                radiuses[i] = Integer.parseInt(args[i]);
            }
        }
        MultipleBouncingBallsAnimation example = new MultipleBouncingBallsAnimation();
        Ball[] balls = example.createBallsArray(radiuses);
        example.drawTheBall(balls);

    }
}
