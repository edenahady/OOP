// ID 318948106
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * this class creates the the single bouncing ball animation.
 */
public class BouncingBallAnimation {
    /**
     * this method draws the single ball animation.
     * @param start is the center point of the ball
     * @param dx is the angle of the ball
     * @param dy is the speed of the ball
     */
    public static void drawAnimation(Point start, double dx, double dy) {
        GUI gui = new GUI("bouncing ball" , 200 , 200);
        Sleeper sleeper = new Sleeper();
        Ball ball = new Ball((int) start.getX() , (int) start.getY() , 30 , java.awt.Color.BLACK);
        Velocity v = Velocity.fromAngleAndSpeed(dx , dy);
        ball.setVelocity(v);
        while (true) {
            ball.moveOneStep();
            ball.keepBallInBorders(200 , 200);
            DrawSurface d = gui.getDrawSurface();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }
    }
    /**
     * this is the main method.
     * @param args doesn't have any use
     */
    public static void main(String[] args) {
        java.util.Random rand = new java.util.Random();
        Point p = new Point(rand.nextInt(200), rand.nextInt(200));
        double dx = rand.nextInt(360);
        double dy = rand.nextInt(12);
        drawAnimation(p , dx , dy);

    }

}
