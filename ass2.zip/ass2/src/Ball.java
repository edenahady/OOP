//ID 318948106
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * this class creates a ball.
 */
public class Ball {
    private Point center;
    private int x;
    private int y;
    private int r;
    private java.awt.Color color;
    private Velocity v;


    // constructor

    /**
     * constructor of a new ball created from a point, radios and color.
     * @param center is the center point
     * @param r is the radius of the ball
     * @param color is the color of the ball
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = center;
        this.r = r;
        this.color = color;
        this.v = new Velocity(0 , 0); // initialization

    }

    /**
     * constructor of a new ball from x of the center Point, y f the center Point, radios and color.
     * @param x is the x coordinate of the center point
     * @param y   is the y coordinate of the center point
     * @param r is the radius of the ball
     * @param color is the color of the ball
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        this.r = r;
        this.color = color;
        this.v = new Velocity(0 , 0);

    }

    // accessors

    /**
     * this method returns the x coordinate of the center point.
     * @return the x coordinate of the center point
     */
    public int getX() {
        return (int) this.center.getX();
    }

    /**
     * this method returns the y coordinate of the center point.
     * @return the y coordinate of the center point
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * this method returns the radius of the ball.
     * @return the radius of the ball
     */
    public int getSize() {
        return this.r;
    }
    /**
     * this method returns the color of the ball.
     * @return the color of the ball
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    // draw the ball on the given DrawSurface

    /**
     * this method is drawing the ball on the surface.
     * @param surface is the board that we draw the ball on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(color);
        surface.fillCircle(this.getX(), this.getY(), this.r);

    }

    /**
     * this method add velocity to the ball.
     * @param v the velocity that added to the ball
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }

    /**
     *  this method returns the velocity of the ball.
     * @return the velocity of the ball
     */

    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * one of two same method that preventing the ball from disappear from the surface.
     * @param width is the width of the surface
     * @param height is the height of the surface
     */
    public void keepBallInBorders(int width , int height) {
        double nextX = this.center.getX() + this.v.getDx();
        double nextY = this.center.getY() + this.v.getDy();
        Velocity v = this.v;
        if (nextX + this.r > width || nextX - this.r < 0) {
            v = new Velocity(-this.v.getDx() , this.v.getDy());
        }
        if (nextY + this.r > height || nextY - this.r < 0) {
            v = new Velocity(this.v.getDx() , -this.v.getDy());
        }
        this.v = v;
    }

    /**
     * this method moved the ball using it velocity.
     */
    public void moveOneStep() {
        this.center = this.getVelocity().applyToPoint(this.center);
    }

    /**
     * second of two same method that preventing the ball from disappear from the surface.
     * @param wStart is the east border
     * @param hStart is the south border
     * @param wEnd is the west border
     * @param hEnd is the north border
     */
    public void keepBallInBorders(int wStart, int hStart, int wEnd, int hEnd) {
        double nextX = this.center.getX() + this.v.getDx();
        double nextY = this.center.getY() + this.v.getDy();
        Velocity v = this.v;
        if (nextX + this.r > wEnd || nextX - this.r < wStart) {
            v = new Velocity(-this.v.getDx() , this.v.getDy());
        }
        if (nextY + this.r > hEnd || nextY - this.r < hStart) {
            v = new Velocity(this.v.getDx() , -this.v.getDy());
        }
        this.v = v;
    }

}


