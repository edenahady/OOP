// ID - 318948106

import biuoop.GUI;
import biuoop.DrawSurface;
import java.util.Random;
import java.awt.Color;
import java.awt.Point;

/**
 * this is a program that crate an abstract art drawing that shows random lines,
 * their middle point and their intersection with each other using line and point classes.
 */
public class AbstractArtDrawing {
    /**
     *
     * @param width is the width of the Surface
     * @param height is the height of the Surface
     * @return random line using coordinates from point class
     */
    public Line generateRandomLine(int width, int height) {
        Random rand = new Random(); // create a random-number generator
        Point start = new Point(rand.nextInt(width) + 1, rand.nextInt(height) + 1);
        Point end = new Point(rand.nextInt(width) + 1, rand.nextInt(height) + 1);
        Line randomLine = new Line(start , end);
        return randomLine;
    }

    /**
     * this function draws the black lines.
     * @param l is the given line
     * @param d the Surface that draws the lines
     */
    public void drawTheLine(Line l, DrawSurface d) {
        int x1 = (int) Math.round(l.start().getX());
        int y1 = (int) Math.round(l.start().getY());
        int x2 = (int) Math.round(l.end().getX());
        int y2 = (int) Math.round(l.end().getY());
        d.setColor(Color.BLACK);
        d.drawLine(x1 , y1 , x2 , y2);
        d.drawText(x1 , y1 , "(" + x1 + "," + y1 + ")", 10);
        d.drawText(x2 , y2 , "(" + x2 + "," + y2 + ")", 10);
    }

    /**
     * this function draws the blue middle points.
     * @param l is the given line
     * @param d the Surface that draws the middle points
     */
    public void drawTheMiddle(Line l, DrawSurface d) {
        int xMid = (int) Math.round(l.middle().getX());
        int yMid = (int) Math.round(l.middle().getY());
        d.setColor(Color.BLUE);
        d.fillCircle(xMid , yMid , 4);
    }

    /**
     * this function draws the red intersection points.
     * @param lines is the lines array that contain all the lines that we drew
     * @param d the Surface that draws the intersection points
     */
    public void drawTheIntersection(Line[] lines , DrawSurface d) {
          for (int i = 0; i < lines.length - 1; ++i) {
              for (int j = i + 1; j < lines.length; ++j) {
                  if (lines[i].isIntersecting(lines[j])) {
                      int xInter = (int) Math.round(lines[i].intersectionWith(lines[j]).getX());
                      int yInter = (int) Math.round(lines[i].intersectionWith(lines[j]).getY());
                      d.setColor(Color.RED);
                      d.fillCircle(xInter, yInter, 4);
                  }
              }
          }
    }

    /**
     * this function creates the lines and send them to the relevant other functions.
     */
    public void drawRandomLines() {
        // Create a window with the title "Random Circles Example"
        // which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("AbstractArtDrawing", 600, 600);
        DrawSurface d = gui.getDrawSurface();
        Line[] lines = new Line[10];
        for (int i = 0; i < 10; ++i) {
            lines[i] = generateRandomLine(500, 500);
            drawTheLine(lines[i], d);
            drawTheMiddle(lines[i], d);
        }
        drawTheIntersection(lines, d);
        gui.show(d);
    }

    /**
     * this is the main method, it's not getting any input.
     * @param args is not in use.
     */
    public static void main(String[] args) {
        AbstractArtDrawing example = new AbstractArtDrawing();
        example.drawRandomLines();
    }
}
