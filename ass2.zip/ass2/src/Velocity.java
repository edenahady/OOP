// ID 318948106
// Velocity specifies the change in position on the `x` and the `y` axes.

/**
 * this class creates the velocity that we want to add to the ball.
 */
public class Velocity {
    private double dx;
    private double dy;
    // constructor

    /**
     * constructor that create velocity from given inputs.
     * @param dx the change in x Axis.
     * @param dy the change in y Axis.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * this method creates new velocity from given angle and speed.
     * @param angle the direction of the ball
     * @param speed the speed of the ball
     * @return the new velocity which created from angle and the speed.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dx = Math.sin(angle) * speed;// moving toward x axis
        double dy = -Math.cos(angle) * speed; // moving toward y axis
        return new Velocity(dx , dy);
    }

    /**
     * this method returned the dx of the velocity.
     * @return the dx of the velocity.
     */
    public double getDx() {
        return this.dx;
    }
    /**
     * this method returned the dy of the velocity.
     * @return the dy of the velocity.
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * this method Take a point with position (x,y) and return a new point.
     *  with position (x+dx, y+dy)
     * @param p is the center point of the ball
     * @return a new point with position (x+dx, y+dy)
     */
    public Point applyToPoint(Point p) {
        double newX = p.getX() + this.dx;
        double newY = p.getY() + this.dy;
        Point newP = new Point(newX , newY);
        return newP;
    }
}
