import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class BinaryExpression extends BaseExpression {
    private Expression  e1;
    private Expression e2;
    public BinaryExpression (Expression e1 , Expression e2) {
        this.e1 = e1;
        this.e2 = e2;
    }


    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return null;
    }

    @Override
    public Boolean evaluate() throws Exception {
        return null;
    }

    @Override
    public List<String> getVariables() {

       List<String> l1 = e1.getVariables();
       List<String> l2 = e2.getVariables();
       if( l1 != null && l2 != null) {
           List<String> newl = new ArrayList<String>();
           newl.addAll(l1);
           newl.addAll(l2);
           return newl;
       }
       return null;
    }
    public Expression getE1() {
        return e1;
    }
    public Expression getE2() {
        return e2;
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return null;
    }
}
