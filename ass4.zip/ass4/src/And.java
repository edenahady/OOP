import java.util.List;
import java.util.Map;

public class And extends BinaryExpression implements Expression{
private Expression andE1;
private Expression andE2;
public And (Expression andE1 , Expression andEe2) {
    super(andE1 , andEe2);
}
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
//        if (assignment.containsKey(this.andE1.getVariables())
//                && assignment.containsKey(this.andE2.getVariables())) {
            return (this.getE1().evaluate(assignment) && this.getE2().evaluate(assignment));
//        } else {
//            throw new Exception("Exception in evaluating variable: \""
//                    + this.andE1.getVariables() + this.andE2.getVariables()
//                    + "\" - there is no assignment to compare with");
//        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.andE1.getVariables() + this.andE2.getVariables()
                + "\" - there is no assignment to compare with");
    }

    @Override
    public Expression assign(String var, Expression expression) {

        return new And(getE1().assign(var , expression) , getE2().assign(var , expression));
    }
    public String toString () {
    return ("(" + this.getE1() + " " + "&" + " " + this.getE2() + ")");
    }
    public Expression nandify() {
        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        return new Nand(new Nand(exp1.nandify() , exp2.nandify())
                , new Nand(exp1.nandify() , exp2.nandify()));
    }

    @Override
    public Expression norify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nor(new Nor(exp1.norify() , exp1.norify()) , new Nor(exp2.norify() , exp2.norify()));
    }

    @Override
    public Expression simplify() {
        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        try {
            if (exp1.toString() == "T") {
                return exp2;
            }
            if (exp2.toString() == "T") {
                return exp1;
            }
            if((exp1.toString() == "F")
                    || (exp2.toString() == "F")) {
                Expression newE = new Val(false);
                return newE;
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        if (exp1.toString() == exp2.toString()) {
            return exp1;
        }
        return new And(exp1 , exp2);
    }
}
