import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Var implements Expression{
    private String variable;
    public Var (String variable) {
        this.variable = variable;
    }
    @Override
    /**
     * this method gets a map that maps keys to values.
     * checks if the map contains the variable.
     * and uses it to evaluate it if it does.
     * @param assignment the given map.
     * @return the evaluated variable.
     * @throws Exception if there is no assignment to compare with.
     */
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        if (assignment.containsKey(this.variable)) {
            return assignment.get(this.variable);
        } else {
            throw new Exception("Exception in evaluating variable: \""
                    + this.variable
                    + "\" - there is no assignment to compare with");
        }
    }

    @Override
    /**
     * this method throws exception if it's called.
     * because it can't evaluate a variable without being given a map.
     * @return the evaluated variable.
     * @throws Exception if there is no assignment to compare with.
     */
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.variable
                + "\" - there is no assignment to compare with");
    }

    @Override
    /**
     * this method returns a 1-size list with the variable in it.
     * @return a list with the variable in it.
     */
    public List<String> getVariables() {
        List<String> list = new ArrayList<String>();
        list.add(this.variable);
        return list;
    }

    @Override
    public Expression assign(String var, Expression expression) {
        if (this.variable.equals(var)) {
            return expression;
        } else {
            return this;
        }
    }

    @Override
    public Expression nandify() {
        return this;
    }

    @Override
    public Expression norify() {
        return this;
    }

    @Override
    public Expression simplify() {
        return this.simplify();
    }

    public String toString() {
        return this.variable;
    }
}
