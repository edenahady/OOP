import java.util.List;
import java.util.Map;

public class Xnor extends BinaryExpression implements Expression{
    private Expression xnorE1;
    private Expression xnorE2;
    public Xnor (Expression xnorE1 , Expression xnorE2) {
        super(xnorE1 , xnorE2);
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
//        if (assignment.containsKey(this.xnorE1.getVariables())
//                && assignment.containsKey(this.xnorE2.getVariables())) {
            return !(this.getE1().evaluate(assignment) ^ this.getE2().evaluate(assignment));
//        } else {
//            throw new Exception("Exception in evaluating variable: \""
//                    + this.xnorE1.getVariables() + this.xnorE2.getVariables()
//                    + "\" - there is no assignment to compare with");
//        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.xnorE1.getVariables() + this.xnorE2.getVariables()
                + "\" - there is no assignment to compare with");
    }


    @Override
    public Expression assign(String var, Expression expression) {

        return new Xnor(getE1().assign(var , expression) , getE2().assign(var , expression));
    }
    public String toString () {
        return ("(" + this.getE1() + " " + "#" + " " + this.getE2() + ")");
    }

    @Override
    public Expression nandify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nand(new Nand(new Nand(exp1.nandify() , exp1.nandify()) , new Nand(exp2.nandify() , exp2.nandify()))
                , new Nand(exp1.nandify() , exp2.nandify()));
    }

    @Override
    public Expression norify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nor(new Nor(exp1.norify() , new Nor(exp1.norify() , exp2.norify())) ,
                new Nor(exp2.norify() , new Nor(exp1.norify() , exp2.norify())));
    }

    @Override
    public Expression simplify() {

        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        if (exp1.toString() == exp2.toString()) {
            return new Val(true);
        }
        return new Xnor(exp1 , exp2);
    }
}
