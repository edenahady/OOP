import java.util.List;
import java.util.Map;

public class Or extends BinaryExpression implements Expression {
    private Expression orE1;
    private Expression orE2;

    public Or(Expression orE1, Expression orEe2) {
        super(orE1, orEe2);
    }

    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
//        if (assignment.containsKey(this.orE1.getVariables())
//                && assignment.containsKey(this.orE2.getVariables())) {
        return (this.getE1().evaluate(assignment) || this.getE2().evaluate(assignment));
//        } else {
//            throw new Exception("Exception in evaluating variable: \""
//                    + this.orE1.getVariables() + this.orE2.getVariables()
//                    + "\" - there is no assignment to compare with");
//        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.orE1.getVariables() + this.orE2.getVariables()
                + "\" - there is no assignment to compare with");
    }


    @Override
    public Expression assign(String var, Expression expression) {

        return new Or(getE1().assign(var, expression), getE2().assign(var, expression));
    }

    public String toString() {
        return ("(" + this.getE1() + " " + "|" + " " + this.getE2() + ")");
    }

    @Override
    public Expression nandify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nand(new Nand(exp1.nandify(), exp1.nandify())
                , new Nand(exp2.nandify(), exp2.nandify()));
    }

    @Override
    public Expression norify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nor(new Nor(exp1.norify(), exp2.norify()), new Nor(exp1.norify(), exp2.norify()));
    }

    @Override
    public Expression simplify() {
        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        try {
            if (exp1.toString() == "F") {
                return exp2;
            }
            if (exp2.toString() == "F") {
                return exp1;
            }
            if ((exp1.toString() == "T")
                    || (exp2.toString() == "T")) {
                Expression newE = new Val(true);
                return newE;
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        if (exp1.toString() == exp2.toString()) {
            return exp1;
        }
        return new Or(exp1, exp2);
    }

}
