import java.sql.SQLOutput;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
public class ExpressionsTest {




    public static void main (String[] args) {
        Map<String, Boolean> m = new TreeMap<String, Boolean>();
        Expression e = new And(new Var("x") , new And(new Var("y") , new Var("z")));
        //Expression a = new Not(new Var("x"));
       m.put("x" , true);
       m.put("y" , false);
       m.put("z" , true);
       System.out.println(e.toString());
        try {
            Boolean b = e.evaluate(m);
            System.out.println(b);
       } catch (Exception exception) {
           System.out.println("not good");
        }
       String s = e.nandify().toString();
        System.out.println(s);
      String g = e.norify().toString();
      System.out.println(g);
//        String k = a.nandify().toString();
//        String q = a.norify().toString();
//        System.out.println(k);
//        System.out.println(q);
//        Expression a = new Xor(new And(new Var("x"), new Val(false)), new Or(new Var("y"), new Val(false)));
        String b = e.simplify().toString();
        System.out.println(b);
//        Expression t = new Val(0);
//        Expression exp = new Xnor(new Var("x") , new Var("x"));
//        Expression newExp = exp.simplify();
//        String l = newExp.toString();
//        System.out.println(l);
    }
}
