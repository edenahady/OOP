import java.util.List;
import java.util.Map;

public class Not extends UnaryExpression implements Expression{
    private Expression e;
    public Not (Expression e) {

        super(e);
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
//        if (assignment.containsKey(this.e.getVariables())) {
            return !(this.getE().evaluate(assignment));
//        } else {
//            throw new Exception("Exception in evaluating variable: \""
//                    + this.e.getVariables()
//                    + "\" - there is no assignment to compare with");
//        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.e.getVariables()
                + "\" - there is no assignment to compare with");
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Not(getE().assign(var , expression));
    }
    public String toString () {
        return ("~" + "(" + this.getE() + ")");
    }
    @Override
    public Expression nandify() {

            Expression exp1 = getE();
            return new Nand(exp1.nandify() , exp1.nandify());


    }

    @Override
    public Expression norify() {
        Expression exp1 = getE();
        return new Nor(exp1.norify() , exp1.norify());
    }

    @Override
    public Expression simplify() {

        return this;
    }
}
