import java.util.List;
import java.util.Map;

public class Nand extends BinaryExpression implements Expression {
    private Expression nandE1;
    private Expression nandE2;
    public Nand (Expression nandE1 , Expression nandE2) {
        super(nandE1 , nandE2);
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
//        if (assignment.containsKey(this.nandE1.getVariables())
//                && assignment.containsKey(this.nandE2.getVariables())) {
            return !(this.getE1().evaluate(assignment) && this.getE2().evaluate(assignment));
//        } else {
//            throw new Exception("Exception in evaluating variable: \""
//                    + this.nandE1.getVariables() + this.nandE2.getVariables()
//                    + "\" - there is no assignment to compare with");
//        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.nandE1.getVariables() + this.nandE2.getVariables()
                + "\" - there is no assignment to compare with");
    }

    @Override
    public Expression assign(String var, Expression expression) {

        return new Nand(getE1().assign(var , expression) , getE2().assign(var , expression));
    }

    @Override
    public Expression nandify() {
        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        return new Nand(exp1.nandify() , exp2.nandify());

    }

    @Override
    public Expression norify() {
        Expression exp1 = getE1();
        Expression exp2 = getE2();
        return new Nor(new Nor(new Nor(exp1.norify() , exp1.norify())
                , new Nor(exp2.norify() , exp2.norify())), new Nor(new Nor(exp1.norify() , exp1.norify())
                , new Nor(exp2.norify() , exp2.norify())));
    }

    @Override
    public Expression simplify() {
        Expression exp1 = this.getE1();
        Expression exp2 = this.getE2();
        try {
            if (exp1.toString() == "T") {
                return new Not(exp2);
            }
            if (exp2.toString() == "T") {
                return new Not(exp1);
            }
            if((exp1.toString() == "F")
                    || (exp2.toString() == "F")) {
                Expression newE = new Val(true);
                return newE;
            }
        } catch (Exception e) {
            System.out.println("Error");
        }
        if (exp1.toString() == exp2.toString()) {
            return new Not(exp1);
        }
        return new Nand(exp1 , exp2);
    }

    public String toString () {
        return ("(" + this.getE1() + " " + "A" + " " + this.getE2() + ")");
}
}
