import java.util.List;
import java.util.Map;

public abstract class UnaryExpression extends BaseExpression{
    private Expression e;
    public UnaryExpression (Expression e) {
        this.e = e;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return null;
    }

    @Override
    public Boolean evaluate() throws Exception {
        return null;
    }

    @Override
    public List<String> getVariables() {

        List<String> l = e.getVariables();
        if (l !=null) {
            return l;
        }
        return null;
    }
    public Expression getE() {
        return this.e;
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return null;
    }
}
