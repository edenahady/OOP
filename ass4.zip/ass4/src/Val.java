import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Val implements Expression{
    private boolean value;

    /**
     *
     * @param value is the value.
     */
    public Val (Boolean value) {

        this.value = value;
    }
    public Val(int num) {
        if (num == 0) {
            this.value = false;
        }
        if (num == 1) {
            this.value = true;
        }
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        if (assignment.containsKey(this.value)) {
            return assignment.get(this.value);
        } else {
            throw new Exception("Exception in evaluating variable: \""
                    + this.value
                    + "\" - there is no assignment to compare with");
        }
    }

    @Override
    public Boolean evaluate() throws Exception {
        throw new Exception("Exception in evaluating variable: \""
                + this.value
                + "\" - there is no assignment to compare with");
    }

    @Override
    public List<String> getVariables() {
        List<String> list = new ArrayList<String>();
        return list;
    }

    @Override
    public Expression assign(String var, Expression expression) {

        return this;
    }

    @Override
    public Expression nandify() {
        return this;
    }

    @Override
    public Expression norify() {
        return this;
    }

    @Override
    public Expression simplify() {
        return this.simplify();
    }

    public String toString() {
       if (this.value == true) {
           return "T";
       }
       return "F";
    }
}
