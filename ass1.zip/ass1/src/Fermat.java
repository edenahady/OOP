import java.lang.Math;
/** @author eden ahady
 * Id 318948106
 */
public class Fermat {
    /**
     * @param args is the input
     * this function prints all the Pythagorean  numbers between a to range
     */
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int range = Integer.parseInt(args[1]);
        boolean check = false; // if one or more Pythagorean is found
        if (n <= 0 || range <= 0) { // checking the input
            System.out.println("Invalid input");
        }
        if (args.length != 2) { // checking the input
            System.out.println("Invalid input");
        }

        for (int i = n; i < range; i++) {
            for (int j = n; j < range; j++) {
                for (int q = n; q < range; q++) {
                   if (Math.pow(i , n) + Math.pow(j , n) == Math.pow(q , n) && (i <= j && j <= q)) {
                        System.out.println(i + "," + j + "," + q);
                        check = true;
                    }
                }
            }
        }
        if (!(check)) {
            System.out.println("no");
        }
    }
}
