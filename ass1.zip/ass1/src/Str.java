/**@author eden ahady
 * Id 318948106
 */
    public class Str {
        /**
         * @param query is the input
         * @param sequence is the input
         * this function print all the substrings the start with query or contains query
         */
       public static void function(String query, String sequence) {
           String[] split = sequence.split("_");
           for (int i = 0; i < split.length; i++) {
               if (split[i].startsWith(query)) { // if the substring starts with query
                   System.out.println(split[i]);
               }
           }
           for (int j = 0; j < split.length; j++) {
               if (split[j].contains(query) && !(split[j].startsWith(query))) { //  if the substring contains query
                   System.out.println(split[j]);
               }
           }
       }

    /**
     * @param args is the input
     * this is the main function that sending the value to the function that does the task
     */
        public static void main(String[] args) {
            if (args.length == 2) {
                function(args[0], args[1]);
            } else {
                System.out.println("Invalid input");
            }
        }
    }

